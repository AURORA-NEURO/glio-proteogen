"""Provisional M11-07 plausibility and negative-control contracts.

The M11-07 dossier requires orthogonal controls, direction and conservation
checks, assay-physics checks, competing-mechanism checks, a plausibility grade,
and visible unresolved conflicts.  Failed controls block release; unsupported
or unresolved cases abstain rather than becoming negative findings.
"""

from __future__ import annotations

from enum import StrEnum
from typing import Final, Literal

from pydantic import Field, model_validator

from glio_proteogen.contracts.m11_07.canonical import (
    canonical_request_digest,
    result_payload_digest,
)
from glio_proteogen.kernel.models import (
    ArtifactReference,
    EvidenceReference,
    ExecutionContext,
    FrozenModel,
    Identifier,
    Limitation,
    NonEmptyStr,
    ProvenanceRecord,
    Sha256Digest,
    SupportDecision,
    SupportStatus,
    UncertaintyProfile,
)

# PROVISIONAL ABI: inferred solely from the M11-07 dossier slice.
M1107_MODULE_ID: Final = "GLIO-PROTEOGEN-M11-07"
M1107_OPERATION: Final = "adjudicate_variant_peptide_plausibility"
M1107_CONTRACT_VERSION: Final = "0.1.0-provisional"
M1107_OUTPUT_MEDIA_TYPE: Final = "application/vnd.glio-proteogen.m11-07+json"
M1107_M1104_RESULT_MEDIA_TYPE: Final = "application/vnd.glio-proteogen.m11-04+json"
M1107_PARENT: Final = "variant_peptide"
M1107_OWNER: Final = "Scientific engineering"
M1107_SAFETY_CLASS: Final = "S2"
M1107_GATE: Final = "G3"
M1107_PROVISIONAL_ABI: Final = True
M1107_MAX_CONTROLS: Final = 128
M1107_MAX_EVALUATIONS: Final = M1107_MAX_CONTROLS
M1107_MAX_CONFLICTS: Final = 128
M1107_MAX_MECHANISMS: Final = 64
M1107_MAX_EVIDENCE: Final = 64
M1107_MAX_FINDINGS: Final = 64
M1107_MIN_COMPETING_MECHANISMS: Final = 2
M1107_MAX_CANONICAL_REQUEST_BYTES: Final = 4 * 1024 * 1024
M1107_MAX_CANONICAL_RESULT_BYTES: Final = 8 * 1024 * 1024
M1107_EVIDENCE_CLAIM: Final = (
    "Caller-declared M11-04 mechanism and M11-07 control evidence; issuer authority "
    "is not authenticated."
)
M1107_REQUIRED_CONTROL_KINDS: Final = (
    "orthogonal_evidence",
    "known_control",
    "direction",
    "conservation",
    "assay_physics",
    "competing_mechanism",
)


class ControlKind(StrEnum):
    ORTHOGONAL_EVIDENCE = "orthogonal_evidence"
    KNOWN_CONTROL = "known_control"
    DIRECTION = "direction"
    CONSERVATION = "conservation"
    ASSAY_PHYSICS = "assay_physics"
    COMPETING_MECHANISM = "competing_mechanism"


class ControlOutcome(StrEnum):
    PASSED = "passed"
    FAILED = "failed"
    NOT_EVALUABLE = "not_evaluable"
    ABSTAINED = "abstained"


class PlausibilityGrade(StrEnum):
    HIGH = "high"
    MODERATE = "moderate"
    LOW = "low"


class PlausibilityAdjudicationStatus(StrEnum):
    ADJUDICATED = "adjudicated"
    ABSTAINED = "abstained"


class PlausibilityFindingCode(StrEnum):
    CONTROL_FAILED = "control_failed"
    CONTROL_NOT_EVALUABLE = "control_not_evaluable"
    UNRESOLVED_CONFLICT = "unresolved_conflict"
    UPSTREAM_UNSUPPORTED = "upstream_unsupported"
    PROVISIONAL_ABI_PENDING_REVIEW = "provisional_abi_pending_review"


class PlausibilityControl(FrozenModel):
    control_id: Identifier
    kind: ControlKind
    criterion: NonEmptyStr
    expected_direction: NonEmptyStr | None = None
    required_evidence: tuple[EvidenceReference, ...] = Field(
        min_length=1, max_length=M1107_MAX_EVIDENCE
    )
    # The assessment is an explicitly caller-declared observation.  The
    # module never opens or interprets the referenced artifact, so an
    # unauthenticated assertion cannot silently become a negative finding.
    declared_outcome: ControlOutcome = ControlOutcome.NOT_EVALUABLE
    observed_direction: NonEmptyStr | None = None
    is_negative_control: bool = False
    release_blocking: Literal[True] = True

    @model_validator(mode="after")
    def negative_control_is_known_control(self) -> PlausibilityControl:
        if self.is_negative_control and self.kind is not ControlKind.KNOWN_CONTROL:
            raise ValueError("negative controls must use the known_control kind")
        return self


class ControlEvaluation(FrozenModel):
    control_id: Identifier
    outcome: ControlOutcome
    observed_direction: NonEmptyStr | None = None
    rationale: NonEmptyStr
    evidence: tuple[EvidenceReference, ...] = Field(default=(), max_length=M1107_MAX_EVIDENCE)


class UnresolvedConflict(FrozenModel):
    conflict_id: Identifier
    description: NonEmptyStr
    competing_mechanisms: tuple[NonEmptyStr, ...] = Field(
        min_length=2, max_length=M1107_MAX_MECHANISMS
    )
    release_blocking: Literal[True] = True
    evidence: tuple[EvidenceReference, ...] = Field(default=(), max_length=M1107_MAX_EVIDENCE)


class PlausibilityFinding(FrozenModel):
    finding_id: Identifier
    code: PlausibilityFindingCode
    message: NonEmptyStr
    evidence: tuple[EvidenceReference, ...] = Field(default=(), max_length=M1107_MAX_EVIDENCE)


class AdjudicateVariantPeptidePlausibilityRequest(FrozenModel):
    """Provisional request bound to the M11-04 mechanism inference result."""

    operation: Literal["adjudicate_variant_peptide_plausibility"] = M1107_OPERATION
    contract_version: Literal["0.1.0-provisional"] = M1107_CONTRACT_VERSION
    request_id: Identifier
    context: ExecutionContext
    mechanism_inference_result: ArtifactReference
    controls: tuple[PlausibilityControl, ...] = Field(min_length=1, max_length=M1107_MAX_CONTROLS)
    candidate_mechanisms: tuple[NonEmptyStr, ...] = Field(
        min_length=2, max_length=M1107_MAX_MECHANISMS
    )
    conflict_declared: bool = False
    source_artifacts: tuple[ArtifactReference, ...] = Field(
        min_length=1, max_length=M1107_MAX_EVIDENCE
    )
    supersedes_result_digest: Sha256Digest | None = None

    @model_validator(mode="after")
    def request_is_bound(self) -> AdjudicateVariantPeptidePlausibilityRequest:
        if self.mechanism_inference_result.media_type != M1107_M1104_RESULT_MEDIA_TYPE:
            raise ValueError("plausibility request must bind the provisional M11-04 result")
        ids = tuple(item.control_id for item in self.controls)
        if len(ids) != len(set(ids)):
            raise ValueError("control ids must be unique")
        kinds = {item.kind.value for item in self.controls}
        if kinds != set(M1107_REQUIRED_CONTROL_KINDS):
            raise ValueError("all six required plausibility control kinds must be present")
        if not any(item.is_negative_control for item in self.controls):
            raise ValueError("at least one known negative control is required")
        if (
            self.conflict_declared
            and len(self.candidate_mechanisms) < M1107_MIN_COMPETING_MECHANISMS
        ):
            raise ValueError("declared conflicts require competing mechanisms")
        return self


class VariantPeptidePlausibilityAdjudicationResult(FrozenModel):
    """Plausibility grade with complete controls and visible conflicts."""

    output_type: Literal["variant_peptide_plausibility_adjudication"] = (
        "variant_peptide_plausibility_adjudication"
    )
    result_id: Identifier
    result_version: Literal["0.1.0-provisional"] = M1107_CONTRACT_VERSION
    request_digest: Sha256Digest
    result_digest: Sha256Digest
    request: AdjudicateVariantPeptidePlausibilityRequest
    status: PlausibilityAdjudicationStatus
    grade: PlausibilityGrade | None = None
    evaluations: tuple[ControlEvaluation, ...] = Field(default=(), max_length=M1107_MAX_EVALUATIONS)
    conflicts: tuple[UnresolvedConflict, ...] = Field(default=(), max_length=M1107_MAX_CONFLICTS)
    findings: tuple[PlausibilityFinding, ...] = Field(default=(), max_length=M1107_MAX_FINDINGS)
    abstention_reason: NonEmptyStr | None = None
    parent_target: Literal["variant_peptide"] = M1107_PARENT
    emits_parent: Literal[False] = False
    support_decision: SupportDecision
    uncertainty: UncertaintyProfile
    provenance: ProvenanceRecord
    evidence: tuple[EvidenceReference, ...] = Field(default=(), max_length=M1107_MAX_EVIDENCE)
    limitations: tuple[Limitation, ...] = Field(min_length=1, max_length=32)
    human_review_required: bool = False

    @model_validator(mode="after")
    def result_is_closed(self) -> VariantPeptidePlausibilityAdjudicationResult:
        if self.request_digest != canonical_request_digest(self.request):
            raise ValueError("result request digest does not bind the exact request")
        control_ids = {item.control_id for item in self.request.controls}
        evaluation_ids = tuple(item.control_id for item in self.evaluations)
        if set(evaluation_ids) != control_ids or len(evaluation_ids) != len(set(evaluation_ids)):
            raise ValueError("every control must have exactly one evaluation")
        evaluation_by_id = {item.control_id: item for item in self.evaluations}
        control_by_id = {item.control_id: item for item in self.request.controls}
        for control_id, control in control_by_id.items():
            evaluation = evaluation_by_id[control_id]
            if evaluation.outcome is not control.declared_outcome:
                raise ValueError("evaluation outcome must bind the caller-declared control outcome")
            if evaluation.observed_direction != control.observed_direction:
                raise ValueError("evaluation direction must bind the caller-declared direction")
        conflict_ids = tuple(item.conflict_id for item in self.conflicts)
        if len(conflict_ids) != len(set(conflict_ids)):
            raise ValueError("conflict ids must be unique")
        blocking_outcomes = {
            ControlOutcome.FAILED,
            ControlOutcome.NOT_EVALUABLE,
            ControlOutcome.ABSTAINED,
        }
        has_blocking_outcome = any(item.outcome in blocking_outcomes for item in self.evaluations)
        if self.status is PlausibilityAdjudicationStatus.ADJUDICATED:
            if (
                self.grade is None
                or self.abstention_reason is not None
                or has_blocking_outcome
                or self.conflicts
                or self.request.conflict_declared
                or self.support_decision.status is not SupportStatus.SUPPORTED
            ):
                raise ValueError("adjudicated result requires all controls passed and no conflicts")
        elif (
            self.grade is not None
            or self.abstention_reason is None
            or self.support_decision.status
            not in {SupportStatus.UNSUPPORTED, SupportStatus.REVIEW_REQUIRED}
            or (self.request.conflict_declared and not self.conflicts)
            or (self.conflicts and not self.human_review_required)
        ):
            raise ValueError("abstained result requires no grade and safe status")
        if self.result_digest != result_payload_digest(self):
            raise ValueError("result digest does not match canonical result content")
        return self


__all__ = [
    "M1107_CONTRACT_VERSION",
    "M1107_EVIDENCE_CLAIM",
    "M1107_GATE",
    "M1107_M1104_RESULT_MEDIA_TYPE",
    "M1107_MAX_CANONICAL_REQUEST_BYTES",
    "M1107_MAX_CANONICAL_RESULT_BYTES",
    "M1107_MAX_CONFLICTS",
    "M1107_MAX_CONTROLS",
    "M1107_MAX_EVALUATIONS",
    "M1107_MAX_EVIDENCE",
    "M1107_MAX_FINDINGS",
    "M1107_MAX_MECHANISMS",
    "M1107_MIN_COMPETING_MECHANISMS",
    "M1107_MODULE_ID",
    "M1107_OPERATION",
    "M1107_OUTPUT_MEDIA_TYPE",
    "M1107_OWNER",
    "M1107_PARENT",
    "M1107_PROVISIONAL_ABI",
    "M1107_REQUIRED_CONTROL_KINDS",
    "M1107_SAFETY_CLASS",
    "AdjudicateVariantPeptidePlausibilityRequest",
    "ControlEvaluation",
    "ControlKind",
    "ControlOutcome",
    "PlausibilityAdjudicationStatus",
    "PlausibilityControl",
    "PlausibilityFinding",
    "PlausibilityFindingCode",
    "PlausibilityGrade",
    "UnresolvedConflict",
    "VariantPeptidePlausibilityAdjudicationResult",
]
