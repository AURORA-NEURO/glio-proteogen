"""Provisional M10-07 calibration and selective-prediction contracts.

The dossier specifies scoped calibration, support thresholds, OOD checks, and
abstention, but does not freeze the public ABI, metrics, or calibration
catalogue.  These symbols are reviewable scaffolding only.
"""

from __future__ import annotations

from enum import StrEnum
from hashlib import sha256
from typing import Final, Literal

from pydantic import Field, model_validator

from glio_proteogen.contracts.m10_07.canonical import (
    canonical_request_digest,
    result_payload_digest,
)
from glio_proteogen.kernel.models import (
    ArtifactReference,
    ControlDecisionRecord,
    ControlRole,
    EstimateState,
    EvidenceReference,
    ExecutionContext,
    FrozenModel,
    Identifier,
    Limitation,
    NonEmptyStr,
    ProvenanceRecord,
    SemanticVersion,
    Sha256Digest,
    SupportDecision,
    SupportStatus,
    UncertaintyEstimate,
    UncertaintyProfile,
)

M1007_MODULE_ID: Final = "GLIO-PROTEOGEN-M10-07"
M1007_OPERATION: Final = "calibrate_protein_rna_discordance_selective_prediction"
M1007_CONTRACT_VERSION: Final = "0.1.0-provisional"
M1007_OUTPUT_MEDIA_TYPE: Final = "application/vnd.glio-proteogen.m10-07+json"
M1007_UNCERTAINTY_MEDIA_TYPE: Final = "application/vnd.glio-proteogen.m10-06+json"
M1007_PARENT: Final = "protein_rna_discordance"
M1007_OWNER: Final = "Platform engineering"
M1007_SAFETY_CLASS: Final = "S2"
M1007_GATE: Final = "G3"
M1007_PROVISIONAL_ABI: Final = True
M1007_MAX_PREDICTION_SET: Final = 256
M1007_MIN_CALIBRATION_OBSERVATIONS: Final = 8
M1007_MAX_CALIBRATION_OBSERVATIONS: Final = 256
M1007_MAX_DIAGNOSTICS: Final = 256
M1007_MAX_EVIDENCE: Final = 64
M1007_MAX_SCOPES: Final = 128
M1007_MAX_CANONICAL_REQUEST_BYTES: Final = 4 * 1024 * 1024
M1007_MAX_CANONICAL_RESULT_BYTES: Final = 8 * 1024 * 1024
M1007_BENCHMARK_ITERATIONS: Final = 10
M1007_MEAN_BUDGET_NS: Final = 2_000_000_000
M1007_P95_BUDGET_NS: Final = 3_000_000_000
M1007_NOMINAL_COVERAGE: Final = 0.9
M1007_MIN_COVERAGE: Final = 0.85
M1007_MAX_COVERAGE: Final = 0.95
M1007_EVIDENCE_CLAIM: Final = (
    "Caller-declared M10-06 uncertainty and calibration evidence; issuer authority "
    "is not authenticated."
)


class CalibrationMethod(StrEnum):
    CONFORMAL = "conformal"
    SCORE_CALIBRATION = "score_calibration"
    SELECTIVE_ENSEMBLE = "selective_ensemble"


class CalibrationStatus(StrEnum):
    CALIBRATED = "calibrated"
    ABSTAINED = "abstained"


class CalibrationReplayReason(StrEnum):
    VERIFIED = "verified"
    INVALID_RESULT = "invalid_result"
    DIGEST_MISMATCH = "digest_mismatch"
    NON_CANONICAL = "non_canonical"
    OVERSIZED = "oversized"


class CalibrationDiagnosticStatus(StrEnum):
    PASS = "pass"  # noqa: S105
    WARNING = "warning"
    FAIL = "fail"
    NOT_EVALUABLE = "not_evaluable"


class CalibrationFindingCode(StrEnum):
    CALIBRATION_NOT_LOCKED = "calibration_not_locked"
    OOD_UNSUPPORTED = "ood_unsupported"
    SUPPORT_THRESHOLD_NOT_MET = "support_threshold_not_met"
    SUBGROUP_DISPARITY = "subgroup_disparity"


class CalibrationScope(FrozenModel):
    """Explicit site/platform/disease/subgroup calibration scope."""

    site: NonEmptyStr
    platform: NonEmptyStr
    disease_class: NonEmptyStr
    subgroup: NonEmptyStr
    evidence: tuple[EvidenceReference, ...] = Field(default=(), max_length=M1007_MAX_EVIDENCE)


class CalibrationObservation(FrozenModel):
    """One labeled glioma calibration residual used by conformal scoring."""

    observation_id: Identifier
    score: float = Field(ge=0.0, le=1.0)
    observed_label: Literal["discordant", "concordant"]
    subgroup: NonEmptyStr
    evidence: tuple[EvidenceReference, ...] = Field(
        min_length=1,
        max_length=M1007_MAX_EVIDENCE,
    )

    @model_validator(mode="after")
    def observation_is_closed(self) -> CalibrationObservation:
        if any(item.role != "evidence" for item in self.evidence):
            raise ValueError("calibration observation evidence must use the evidence role")
        return self


class CalibrationConfiguration(FrozenModel):
    """Locked calibration and selective-support policy."""

    configuration_id: Identifier
    version: SemanticVersion
    method: CalibrationMethod
    scopes: tuple[CalibrationScope, ...] = Field(min_length=1, max_length=M1007_MAX_SCOPES)
    nominal_coverage: float = Field(default=M1007_NOMINAL_COVERAGE, ge=0.0, le=1.0)
    support_threshold: float = Field(ge=0.0, le=1.0)
    ood_threshold: float = Field(ge=0.0, le=1.0)
    calibration_artifact: ArtifactReference
    benchmark_artifact: ArtifactReference
    locked: Literal[True] = True
    evidence: tuple[EvidenceReference, ...] = Field(default=(), max_length=M1007_MAX_EVIDENCE)

    @model_validator(mode="after")
    def scopes_are_unique(self) -> CalibrationConfiguration:
        keys = tuple(
            (item.site, item.platform, item.disease_class, item.subgroup) for item in self.scopes
        )
        if len(keys) != len(set(keys)):
            raise ValueError("calibration scopes must be unique")
        if self.nominal_coverage != M1007_NOMINAL_COVERAGE:
            raise ValueError("provisional selective coverage target must be nominal 90 percent")
        return self


class CalibratedEstimate(FrozenModel):
    predicted_discordance: NonEmptyStr
    score: float = Field(ge=0.0, le=1.0)
    calibrated_confidence: float = Field(ge=0.0, le=1.0)
    calibration_reference: ArtifactReference
    evidence: tuple[EvidenceReference, ...] = Field(default=(), max_length=M1007_MAX_EVIDENCE)


class PredictionSet(FrozenModel):
    labels: tuple[NonEmptyStr, ...] = Field(min_length=1, max_length=M1007_MAX_PREDICTION_SET)
    nominal_coverage: float = Field(ge=0.0, le=1.0)
    evidence: tuple[EvidenceReference, ...] = Field(default=(), max_length=M1007_MAX_EVIDENCE)

    @model_validator(mode="after")
    def labels_are_unique(self) -> PredictionSet:
        if len(self.labels) != len(set(self.labels)):
            raise ValueError("prediction-set labels must be unique")
        return self


class CalibrationDiagnostic(FrozenModel):
    diagnostic_id: Identifier
    status: CalibrationDiagnosticStatus
    metric_name: NonEmptyStr
    metric_value: float | None = Field(default=None, ge=0.0, le=1.0)
    subgroup: NonEmptyStr | None = None
    message: NonEmptyStr
    evidence: tuple[EvidenceReference, ...] = Field(default=(), max_length=M1007_MAX_EVIDENCE)


class CalibrateProteinRnaDiscordanceSelectivePredictionVerification(FrozenModel):
    """Content and deterministic replay status for one selective result."""

    content_verified: bool
    deterministic_verified: bool
    verified: bool
    result_digest: Sha256Digest | None = None
    reason: CalibrationReplayReason

    @model_validator(mode="after")
    def flags_are_closed(
        self,
    ) -> CalibrateProteinRnaDiscordanceSelectivePredictionVerification:
        expected = self.content_verified and self.deterministic_verified
        if self.verified != expected:
            raise ValueError("verified must equal content and deterministic verification")
        if self.verified != (self.result_digest is not None):
            raise ValueError("verified results must carry a result digest only")
        return self


class CalibrateProteinRnaDiscordanceSelectivePredictionRequest(FrozenModel):
    """Provisional request bound to the complete M10-06 uncertainty result."""

    operation: Literal["calibrate_protein_rna_discordance_selective_prediction"] = M1007_OPERATION
    contract_version: Literal["0.1.0-provisional"] = M1007_CONTRACT_VERSION
    request_id: Identifier
    context: ExecutionContext
    uncertainty_result: ArtifactReference
    configuration: CalibrationConfiguration
    source_artifacts: tuple[ArtifactReference, ...] = Field(
        min_length=1, max_length=M1007_MAX_EVIDENCE
    )
    calibration_observations: tuple[CalibrationObservation, ...] = Field(
        default=(),
        max_length=M1007_MAX_CALIBRATION_OBSERVATIONS,
    )
    query_score: float | None = Field(default=None, ge=0.0, le=1.0)
    query_subgroup: NonEmptyStr | None = None
    supersedes_result_digest: Sha256Digest | None = None

    @model_validator(mode="after")
    def request_is_bound(
        self,
    ) -> CalibrateProteinRnaDiscordanceSelectivePredictionRequest:
        if self.uncertainty_result.media_type != M1007_UNCERTAINTY_MEDIA_TYPE:
            raise ValueError("calibration request must bind the provisional M10-06 result")
        observation_ids = tuple(item.observation_id for item in self.calibration_observations)
        if len(observation_ids) != len(set(observation_ids)):
            raise ValueError("calibration observation identifiers must be unique")
        if self.calibration_observations and self.query_score is None:
            raise ValueError("measured calibration requires a query score")
        if (
            self.calibration_observations
            and len(self.calibration_observations) < M1007_MIN_CALIBRATION_OBSERVATIONS
        ):
            raise ValueError(
                "measured calibration requires at least eight labeled observations"
            )
        if self.query_score is not None and self.query_subgroup is None:
            raise ValueError("a measured query score requires a query subgroup")
        if self.query_score is None and self.query_subgroup is not None:
            raise ValueError("query subgroup cannot be supplied without a query score")
        return self


class ProteinRnaDiscordanceSelectivePredictionResult(FrozenModel):
    """Calibrated estimate, prediction set, and support decision with safe status."""

    output_type: Literal["protein_rna_discordance_selective_prediction"] = (
        "protein_rna_discordance_selective_prediction"
    )
    result_id: Identifier
    result_version: Literal["0.1.0-provisional"] = M1007_CONTRACT_VERSION
    request_digest: Sha256Digest
    result_digest: Sha256Digest
    request: CalibrateProteinRnaDiscordanceSelectivePredictionRequest
    status: CalibrationStatus
    estimate: CalibratedEstimate | None = None
    prediction_set: PredictionSet | None = None
    diagnostics: tuple[CalibrationDiagnostic, ...] = Field(
        min_length=1, max_length=M1007_MAX_DIAGNOSTICS
    )
    findings: tuple[CalibrationFindingCode, ...] = Field(default=(), max_length=32)
    abstention_reason: NonEmptyStr | None = None
    parent_target: Literal["protein_rna_discordance"] = M1007_PARENT
    emits_parent: Literal[False] = False
    support_decision: SupportDecision
    uncertainty: UncertaintyProfile
    provenance: ProvenanceRecord
    evidence: tuple[EvidenceReference, ...] = Field(default=(), max_length=M1007_MAX_EVIDENCE)
    limitations: tuple[Limitation, ...] = Field(min_length=1, max_length=32)
    human_review_required: bool = False

    @model_validator(mode="after")
    def result_is_closed(self) -> ProteinRnaDiscordanceSelectivePredictionResult:
        if self.request_digest != canonical_request_digest(self.request):
            raise ValueError("result request digest does not bind the exact request")
        expected_result_id = f"result.{self.request_digest.removeprefix('sha256:')}"
        if self.result_id != expected_result_id:
            raise ValueError("result identifier does not bind the request digest")
        failed = {
            CalibrationDiagnosticStatus.FAIL,
            CalibrationDiagnosticStatus.NOT_EVALUABLE,
        }
        if self.status is CalibrationStatus.CALIBRATED:
            if (
                self.estimate is None
                or self.prediction_set is None
                or self.abstention_reason is not None
                or self.support_decision.status is not SupportStatus.SUPPORTED
                or any(item.status in failed for item in self.diagnostics)
            ):
                raise ValueError("calibrated result requires supported, evaluable output")
            if self.prediction_set.nominal_coverage != M1007_NOMINAL_COVERAGE:
                raise ValueError("calibrated prediction set requires nominal 90 percent coverage")
        elif (
            self.estimate is not None
            or self.prediction_set is not None
            or self.abstention_reason is None
            or self.support_decision.status
            not in {SupportStatus.UNSUPPORTED, SupportStatus.REVIEW_REQUIRED}
        ):
            raise ValueError("abstained result requires no prediction and explicit safe status")
        diagnostic_ids = tuple(item.diagnostic_id for item in self.diagnostics)
        if len(diagnostic_ids) != len(set(diagnostic_ids)):
            raise ValueError("calibration diagnostic ids must be unique")
        if len(self.findings) != len(set(self.findings)):
            raise ValueError("calibration findings must be unique")
        if self.evidence != expected_evidence(self.request):
            raise ValueError("result evidence does not bind the exact request sources")
        if self.uncertainty != expected_uncertainty(self.request_digest):
            raise ValueError("result uncertainty does not match deterministic calibration")
        if not provenance_is_bound(self.request, self.request_digest, self.provenance):
            raise ValueError("result provenance does not bind the exact request context")
        if self.result_digest != result_payload_digest(self):
            raise ValueError("result digest does not match canonical result content")
        return self


def expected_evidence(
    request: CalibrateProteinRnaDiscordanceSelectivePredictionRequest,
) -> tuple[EvidenceReference, ...]:
    """Project the immutable calibration inputs into result evidence."""

    artifacts = (
        request.uncertainty_result,
        request.configuration.calibration_artifact,
        request.configuration.benchmark_artifact,
        *request.source_artifacts,
    )
    references = tuple(
        EvidenceReference(reference=item, role="evidence", claim=M1007_EVIDENCE_CLAIM)
        for item in artifacts
    )
    observations = tuple(
        evidence
        for observation in request.calibration_observations
        for evidence in observation.evidence
    )
    return tuple(dict.fromkeys(references + observations))


def expected_input_digests(
    request: CalibrateProteinRnaDiscordanceSelectivePredictionRequest,
) -> tuple[Sha256Digest, ...]:
    """Return sorted source digests bound into deterministic provenance."""

    return tuple(
        sorted(
            {
                request.uncertainty_result.digest,
                request.configuration.calibration_artifact.digest,
                request.configuration.benchmark_artifact.digest,
                *(item.digest for item in request.source_artifacts),
                *(
                    evidence.reference.digest
                    for observation in request.calibration_observations
                    for evidence in observation.evidence
                ),
            }
        )
    )


def expected_uncertainty(digest: Sha256Digest) -> UncertaintyProfile:
    """Return the deterministic provisional uncertainty profile for a request."""

    def one(name: str) -> UncertaintyEstimate:
        raw = int.from_bytes(sha256(f"{digest}|{name}|m10-07".encode()).digest()[:8], "big") / 2**64
        return UncertaintyEstimate(
            state=EstimateState.ESTIMATED,
            probability=round(0.05 + raw * 0.3, 8),
            rationale=(
                f"Deterministic provisional {name} uncertainty from scoped calibration inputs."
            ),
        )

    return UncertaintyProfile(
        measurement=one("measurement"),
        sampling=one("sampling"),
        parameter=one("parameter"),
        model_form=one("model_form"),
        identification=one("identification"),
        support=one("support"),
        transport=one("transport"),
        sensitivity_notes=(
            "Nominal selective coverage is 90% within the provisional 85-95% envelope.",
        ),
    )


def provenance_is_bound(
    request: CalibrateProteinRnaDiscordanceSelectivePredictionRequest,
    request_digest: Sha256Digest,
    provenance: ProvenanceRecord,
) -> bool:
    """Check request, control, consent, and source digest provenance closure."""

    refs = request.context.references
    expected_controls = (
        ControlDecisionRecord(
            role=ControlRole.APPROVED_CONFIGURATION,
            decision_id=refs.approved_configuration.decision_id,
            state=refs.approved_configuration.state.value,
            policy_version=refs.approved_configuration.policy_version,
            evidence_digest=refs.approved_configuration.evidence.digest,
        ),
        ControlDecisionRecord(
            role=ControlRole.IDENTITY_LINEAGE,
            decision_id=refs.identity_lineage.decision_id,
            state=refs.identity_lineage.state.value,
            policy_version=refs.identity_lineage.policy_version,
            evidence_digest=refs.identity_lineage.evidence.digest,
            subject_digest=refs.identity_lineage.binding_digest,
        ),
        ControlDecisionRecord(
            role=ControlRole.PROVENANCE,
            decision_id=refs.provenance.decision_id,
            state=refs.provenance.state.value,
            policy_version=refs.provenance.policy_version,
            evidence_digest=refs.provenance.evidence.digest,
        ),
        ControlDecisionRecord(
            role=ControlRole.CONSENT,
            decision_id=refs.consent.decision_id,
            state=refs.consent.state.value,
            policy_version=refs.consent.policy_version,
            evidence_digest=refs.consent.evidence.digest,
        ),
        ControlDecisionRecord(
            role=ControlRole.QUALITY,
            decision_id=refs.quality.decision_id,
            state=refs.quality.state.value,
            policy_version=refs.quality.policy_version,
            evidence_digest=refs.quality.evidence.digest,
        ),
        ControlDecisionRecord(
            role=ControlRole.SUPPORT,
            decision_id=refs.support.decision_id,
            state=refs.support.state.value,
            policy_version=refs.support.policy_version,
            evidence_digest=refs.support.evidence.digest,
        ),
        ControlDecisionRecord(
            role=ControlRole.INTENDED_USE,
            decision_id=refs.intended_use.decision_id,
            state=refs.intended_use.state.value,
            policy_version=refs.intended_use.policy_version,
            evidence_digest=refs.intended_use.evidence.digest,
        ),
    )
    actual = {item.role: item for item in provenance.control_decisions}
    return (
        provenance.activity_id == f"activity.{request_digest.removeprefix('sha256:')}"
        and provenance.actor_id == request.context.actor_id
        and provenance.module_id == M1007_MODULE_ID
        and provenance.module_version == M1007_CONTRACT_VERSION
        and provenance.input_digests == expected_input_digests(request)
        and provenance.configuration_digest == refs.approved_configuration.evidence.digest
        and provenance.consent_decision_id == refs.consent.decision_id
        and provenance.consent_state is refs.consent.state
        and provenance.consent_policy_version == refs.consent.policy_version
        and provenance.consent_evidence_digest == refs.consent.evidence.digest
        and len(provenance.control_decisions) == len(expected_controls)
        and set(actual) == {item.role for item in expected_controls}
        and all(actual.get(expected.role) == expected for expected in expected_controls)
    )


__all__ = [
    "M1007_BENCHMARK_ITERATIONS",
    "M1007_CONTRACT_VERSION",
    "M1007_EVIDENCE_CLAIM",
    "M1007_GATE",
    "M1007_MAX_CALIBRATION_OBSERVATIONS",
    "M1007_MAX_CANONICAL_REQUEST_BYTES",
    "M1007_MAX_CANONICAL_RESULT_BYTES",
    "M1007_MAX_COVERAGE",
    "M1007_MAX_DIAGNOSTICS",
    "M1007_MAX_EVIDENCE",
    "M1007_MAX_PREDICTION_SET",
    "M1007_MAX_SCOPES",
    "M1007_MEAN_BUDGET_NS",
    "M1007_MIN_CALIBRATION_OBSERVATIONS",
    "M1007_MIN_COVERAGE",
    "M1007_MODULE_ID",
    "M1007_NOMINAL_COVERAGE",
    "M1007_OPERATION",
    "M1007_OUTPUT_MEDIA_TYPE",
    "M1007_OWNER",
    "M1007_P95_BUDGET_NS",
    "M1007_PARENT",
    "M1007_PROVISIONAL_ABI",
    "M1007_SAFETY_CLASS",
    "M1007_UNCERTAINTY_MEDIA_TYPE",
    "CalibrateProteinRnaDiscordanceSelectivePredictionRequest",
    "CalibrateProteinRnaDiscordanceSelectivePredictionVerification",
    "CalibratedEstimate",
    "CalibrationConfiguration",
    "CalibrationDiagnostic",
    "CalibrationDiagnosticStatus",
    "CalibrationFindingCode",
    "CalibrationMethod",
    "CalibrationObservation",
    "CalibrationReplayReason",
    "CalibrationScope",
    "CalibrationStatus",
    "PredictionSet",
    "ProteinRnaDiscordanceSelectivePredictionResult",
    "expected_evidence",
    "expected_input_digests",
    "expected_uncertainty",
    "provenance_is_bound",
]
