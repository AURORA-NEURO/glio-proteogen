"""Provisional M11-06 perturbation and sensitivity simulator contracts.

The M11-06 dossier requires in-silico perturbations, parameter sweeps,
alternative priors, assay perturbations, mechanism stress tests, sensitivity
surfaces, bounded responses, explicit assumptions, and safe abstention.  It
does not freeze the public ABI, scenario catalogue, operation, media type, or
capacities.  All symbols here are provisional scaffolding pending owner
review.
"""

from __future__ import annotations

from enum import StrEnum
from math import isfinite
from typing import Final, Literal

from pydantic import Field, model_validator

from glio_proteogen.contracts.m11_06.canonical import (
    canonical_request_digest,
    result_payload_digest,
)
from glio_proteogen.kernel.models import (
    ArtifactReference,
    ControlDecisionRecord,
    ControlRole,
    EstimateState,
    EvidenceReference,
    ExecutionContext,
    FrozenModel,
    Identifier,
    Limitation,
    NonEmptyStr,
    ProvenanceRecord,
    SemanticVersion,
    Sha256Digest,
    SupportDecision,
    SupportStatus,
    UncertaintyEstimate,
    UncertaintyProfile,
)

# PROVISIONAL ABI: inferred solely from the M11-06 dossier slice.
M1106_MODULE_ID: Final = "GLIO-PROTEOGEN-M11-06"
M1106_OPERATION: Final = "simulate_variant_peptide_perturbations"
M1106_CONTRACT_VERSION: Final = "0.1.0-provisional"
M1106_OUTPUT_MEDIA_TYPE: Final = "application/vnd.glio-proteogen.m11-06+json"
M1106_M1105_INPUT_MEDIA_TYPE: Final = "application/vnd.glio-proteogen.m11-05+json"
M1106_PARENT: Final = "variant_peptide"
M1106_OWNER: Final = "Platform engineering"
M1106_SAFETY_CLASS: Final = "S2"
M1106_GATE: Final = "G2"
M1106_PROVISIONAL_ABI: Final = True
M1106_MAX_SCENARIOS: Final = 512
M1106_MAX_TARGETS: Final = 2_048
M1106_MAX_RESPONSES: Final = M1106_MAX_SCENARIOS
M1106_MAX_EVIDENCE: Final = 64
M1106_MAX_DIAGNOSTICS: Final = 128
M1106_MAX_FINDINGS: Final = 64
M1106_MAX_REPLICATES: Final = 64
M1106_MINIMUM_REPLICATES_PER_ARM: Final = 3
M1106_MAX_BOOTSTRAP_REPLICATES: Final = 256
M1106_DEFAULT_BOOTSTRAP_REPLICATES: Final = 64
M1106_MAX_CANONICAL_REQUEST_BYTES: Final = 4 * 1024 * 1024
M1106_MAX_CANONICAL_RESULT_BYTES: Final = 8 * 1024 * 1024
M1106_EVIDENCE_CLAIM: Final = (
    "Caller-declared M11-06 perturbation and sensitivity evidence; issuer authority "
    "is not authenticated."
)


class PerturbationKind(StrEnum):
    IN_SILICO = "in_silico"
    PARAMETER_SWEEP = "parameter_sweep"
    ALTERNATIVE_PRIOR = "alternative_prior"
    ASSAY_PERTURBATION = "assay_perturbation"
    MECHANISM_STRESS = "mechanism_stress"


class PerturbationResponseStatus(StrEnum):
    BOUNDED = "bounded"
    OUT_OF_ENVELOPE = "out_of_envelope"
    NOT_EVALUABLE = "not_evaluable"
    ABSTAINED = "abstained"


class SensitivitySimulationStatus(StrEnum):
    SIMULATED = "simulated"
    ABSTAINED = "abstained"


class SensitivityDiagnosticStatus(StrEnum):
    PASS = "pass"  # noqa: S105
    WARNING = "warning"
    FAIL = "fail"
    NOT_EVALUABLE = "not_evaluable"


class SensitivityFindingCode(StrEnum):
    INPUT_INCOMPLETE = "input_incomplete"
    RESPONSE_OUT_OF_ENVELOPE = "response_out_of_envelope"
    ASSUMPTION_UNRESOLVED = "assumption_unresolved"
    NEGATIVE_CONTROL_FAILED = "negative_control_failed"
    UPSTREAM_UNSUPPORTED = "upstream_unsupported"
    PROVISIONAL_ABI_PENDING_REVIEW = "provisional_abi_pending_review"


class PerturbationSpecification(FrozenModel):
    perturbation_id: Identifier
    kind: PerturbationKind
    target_ids: tuple[Identifier, ...] = Field(min_length=1, max_length=M1106_MAX_TARGETS)
    parameter: NonEmptyStr
    baseline_value: NonEmptyStr
    perturbed_value: NonEmptyStr
    rationale: NonEmptyStr
    baseline_measurements: tuple[float, ...] = Field(default=(), max_length=M1106_MAX_REPLICATES)
    perturbed_measurements: tuple[float, ...] = Field(default=(), max_length=M1106_MAX_REPLICATES)
    quality_weight: float = Field(default=1.0, ge=0.0, le=1.0)
    alternative_prior: ArtifactReference | None = None
    assay_artifact: ArtifactReference | None = None
    evidence: tuple[EvidenceReference, ...] = Field(default=(), max_length=M1106_MAX_EVIDENCE)

    @model_validator(mode="after")
    def perturbation_shape_is_closed(self) -> PerturbationSpecification:
        numeric = (*self.baseline_measurements, *self.perturbed_measurements, self.quality_weight)
        if any(not isfinite(number) for number in numeric):
            raise ValueError("perturbation measurements must contain finite numbers")
        if bool(self.baseline_measurements) != bool(self.perturbed_measurements):
            raise ValueError("baseline and perturbed measurements must be supplied together")
        if self.baseline_measurements and (
            len(self.baseline_measurements) < M1106_MINIMUM_REPLICATES_PER_ARM
            or len(self.perturbed_measurements) < M1106_MINIMUM_REPLICATES_PER_ARM
        ):
            raise ValueError("typed perturbations require at least three replicates per arm")
        if self.baseline_value == self.perturbed_value:
            raise ValueError("perturbation baseline and perturbed values must differ")
        if self.kind is PerturbationKind.ALTERNATIVE_PRIOR and self.alternative_prior is None:
            raise ValueError("alternative-prior perturbation requires a prior artifact")
        if self.kind is PerturbationKind.ASSAY_PERTURBATION and self.assay_artifact is None:
            raise ValueError("assay perturbation requires an assay artifact")
        return self


class SensitivityResponse(FrozenModel):
    scenario_id: Identifier
    status: PerturbationResponseStatus
    response_value: float | None = None
    lower_bound: float | None = None
    upper_bound: float | None = None
    raw_effect_delta: float | None = None
    sensitivity_standard_error: float | None = Field(default=None, gt=0.0)
    replicate_count: int | None = Field(default=None, ge=0, le=M1106_MAX_REPLICATES * 2)
    assumptions: tuple[NonEmptyStr, ...] = Field(min_length=1, max_length=64)
    evidence: tuple[EvidenceReference, ...] = Field(default=(), max_length=M1106_MAX_EVIDENCE)

    @model_validator(mode="after")
    def response_bounds_are_closed(self) -> SensitivityResponse:
        numeric = (
            self.response_value,
            self.lower_bound,
            self.upper_bound,
            self.raw_effect_delta,
            self.sensitivity_standard_error,
        )
        if any(number is not None and not isfinite(number) for number in numeric):
            raise ValueError("sensitivity response must contain finite numbers")
        has_bounds = self.lower_bound is not None or self.upper_bound is not None
        if self.status is PerturbationResponseStatus.BOUNDED:
            if (
                self.response_value is None
                or self.lower_bound is None
                or self.upper_bound is None
                or self.lower_bound > self.upper_bound
                or not self.lower_bound <= self.response_value <= self.upper_bound
            ):
                raise ValueError("bounded response requires ordered bounds containing response")
        elif (
            self.response_value is not None
            or has_bounds
            or self.raw_effect_delta is not None
            or self.sensitivity_standard_error is not None
            or self.replicate_count is not None
        ):
            raise ValueError("non-bounded response cannot carry response values")
        return self


class SensitivitySimulationConfiguration(FrozenModel):
    configuration_id: Identifier
    version: SemanticVersion
    model_family: NonEmptyStr
    reference_artifact: ArtifactReference
    maximum_scenarios: int = Field(gt=0, le=M1106_MAX_SCENARIOS)
    bootstrap_replicates: int = Field(
        default=M1106_DEFAULT_BOOTSTRAP_REPLICATES,
        ge=16,
        le=M1106_MAX_BOOTSTRAP_REPLICATES,
    )
    locked: Literal[True] = True
    negative_control_artifact: ArtifactReference | None = None
    evidence: tuple[EvidenceReference, ...] = Field(default=(), max_length=M1106_MAX_EVIDENCE)

    @model_validator(mode="after")
    def configuration_is_closed(self) -> SensitivitySimulationConfiguration:
        return self


class SensitivitySurface(FrozenModel):
    """Versioned surface mapping every scenario to one explicit response."""

    surface_id: Identifier
    version: SemanticVersion
    baseline_result: ArtifactReference
    perturbations: tuple[PerturbationSpecification, ...] = Field(
        min_length=1, max_length=M1106_MAX_SCENARIOS
    )
    responses: tuple[SensitivityResponse, ...] = Field(min_length=1, max_length=M1106_MAX_RESPONSES)
    configuration: SensitivitySimulationConfiguration
    evidence: tuple[EvidenceReference, ...] = Field(default=(), max_length=M1106_MAX_EVIDENCE)

    @model_validator(mode="after")
    def surface_is_closed(self) -> SensitivitySurface:
        scenario_ids = tuple(item.perturbation_id for item in self.perturbations)
        response_ids = tuple(item.scenario_id for item in self.responses)
        if len(scenario_ids) != len(set(scenario_ids)):
            raise ValueError("perturbation identifiers must be unique")
        if len(response_ids) != len(set(response_ids)):
            raise ValueError("sensitivity response identifiers must be unique")
        if set(scenario_ids) != set(response_ids):
            raise ValueError("every perturbation must have exactly one sensitivity response")
        if self.baseline_result.media_type != M1106_M1105_INPUT_MEDIA_TYPE:
            raise ValueError("surface must bind the provisional M11-05 baseline result")
        if len(self.perturbations) > self.configuration.maximum_scenarios:
            raise ValueError("surface exceeds the locked configuration scenario limit")
        return self


class SensitivityDiagnostic(FrozenModel):
    diagnostic_id: Identifier
    status: SensitivityDiagnosticStatus
    message: NonEmptyStr
    evidence: tuple[EvidenceReference, ...] = Field(default=(), max_length=M1106_MAX_EVIDENCE)


class SimulateVariantPeptidePerturbationsRequest(FrozenModel):
    """Provisional request ABI bound to the M11-05 upstream result."""

    operation: Literal["simulate_variant_peptide_perturbations"] = M1106_OPERATION
    contract_version: Literal["0.1.0-provisional"] = M1106_CONTRACT_VERSION
    request_id: Identifier
    context: ExecutionContext
    upstream_result: ArtifactReference
    configuration: SensitivitySimulationConfiguration
    perturbations: tuple[PerturbationSpecification, ...] = Field(
        min_length=1, max_length=M1106_MAX_SCENARIOS
    )
    source_artifacts: tuple[ArtifactReference, ...] = Field(
        min_length=1, max_length=M1106_MAX_EVIDENCE
    )
    supersedes_result_digest: Sha256Digest | None = None

    @model_validator(mode="after")
    def request_is_bound(self) -> SimulateVariantPeptidePerturbationsRequest:
        if self.upstream_result.media_type != M1106_M1105_INPUT_MEDIA_TYPE:
            raise ValueError("request must bind the provisional M11-05 upstream result")
        ids = tuple(item.perturbation_id for item in self.perturbations)
        if len(ids) != len(set(ids)):
            raise ValueError("request perturbation identifiers must be unique")
        return self


class VariantPeptideSensitivitySimulationResult(FrozenModel):
    """Sensitivity surface with bounded responses and explicit abstention."""

    output_type: Literal["variant_peptide_sensitivity_surface"] = (
        "variant_peptide_sensitivity_surface"
    )
    result_id: Identifier
    result_version: Literal["0.1.0-provisional"] = M1106_CONTRACT_VERSION
    request_digest: Sha256Digest
    result_digest: Sha256Digest
    request: SimulateVariantPeptidePerturbationsRequest
    status: SensitivitySimulationStatus
    surface: SensitivitySurface | None = None
    diagnostics: tuple[SensitivityDiagnostic, ...] = Field(
        min_length=1, max_length=M1106_MAX_DIAGNOSTICS
    )
    findings: tuple[SensitivityFindingCode, ...] = Field(default=(), max_length=M1106_MAX_FINDINGS)
    abstention_reason: NonEmptyStr | None = None
    parent_target: Literal["variant_peptide"] = M1106_PARENT
    emits_parent: Literal[False] = False
    support_decision: SupportDecision
    uncertainty: UncertaintyProfile
    provenance: ProvenanceRecord
    evidence: tuple[EvidenceReference, ...] = Field(default=(), max_length=M1106_MAX_EVIDENCE)
    limitations: tuple[Limitation, ...] = Field(min_length=1, max_length=32)
    human_review_required: bool = False

    @model_validator(mode="after")
    def result_is_closed(self) -> VariantPeptideSensitivitySimulationResult:
        if self.request_digest != canonical_request_digest(self.request):
            raise ValueError("result request digest does not bind the exact request")
        unsafe_statuses = {
            PerturbationResponseStatus.OUT_OF_ENVELOPE,
            PerturbationResponseStatus.NOT_EVALUABLE,
            PerturbationResponseStatus.ABSTAINED,
        }
        if self.status is SensitivitySimulationStatus.SIMULATED:
            if (
                self.surface is None
                or self.abstention_reason is not None
                or self.support_decision.status is not SupportStatus.SUPPORTED
                or any(item.status in unsafe_statuses for item in self.surface.responses)
            ):
                raise ValueError("simulated result requires supported bounded responses")
            if self.human_review_required:
                raise ValueError("simulated result cannot require human review")
        elif (
            self.surface is not None
            or self.abstention_reason is None
            or self.support_decision.status
            not in {SupportStatus.UNSUPPORTED, SupportStatus.REVIEW_REQUIRED}
        ):
            raise ValueError("abstained result requires no surface and safe status")
        if self.status is SensitivitySimulationStatus.ABSTAINED and not self.human_review_required:
            raise ValueError("abstained result requires human review")
        if self.result_digest != result_payload_digest(self):
            raise ValueError("result digest does not match canonical result content")
        return self


def expected_uncertainty(*, supported: bool) -> UncertaintyProfile:
    """Return a conservative seven-dimension uncertainty profile.

    The simulator never invents confidence for an unsupported perturbation.  A
    supported robust replicate response is estimated but still records the
    transport and model-form limitations that remain provisional.
    """

    probability = 0.1 if supported else None
    state = "estimated" if supported else "not_estimable"
    rationale = (
        "Robust replicate finite-difference response with deterministic bootstrap bounds."
        if supported
        else "No uncertainty estimate is published after a safety-gated abstention."
    )

    def estimate() -> UncertaintyEstimate:
        return UncertaintyEstimate(
            state=EstimateState(state), probability=probability, rationale=rationale
        )

    return UncertaintyProfile(
        measurement=estimate(),
        sampling=estimate(),
        parameter=estimate(),
        model_form=estimate(),
        identification=estimate(),
        support=estimate(),
        transport=estimate(),
        sensitivity_notes=(
            "Responses are bounded sensitivity projections, not causal treatment effects.",
            "Alternative priors and assay perturbations remain caller-declared references.",
        ),
    )


def expected_provenance(
    request: SimulateVariantPeptidePerturbationsRequest,
    request_digest: Sha256Digest,
) -> ProvenanceRecord:
    """Build module-local provenance from the immutable request controls."""

    refs = request.context.references
    controls = (
        ControlDecisionRecord(
            role=ControlRole.APPROVED_CONFIGURATION,
            decision_id=refs.approved_configuration.decision_id,
            state=refs.approved_configuration.state.value,
            policy_version=refs.approved_configuration.policy_version,
            evidence_digest=refs.approved_configuration.evidence.digest,
        ),
        ControlDecisionRecord(
            role=ControlRole.IDENTITY_LINEAGE,
            decision_id=refs.identity_lineage.decision_id,
            state=refs.identity_lineage.state.value,
            policy_version=refs.identity_lineage.policy_version,
            evidence_digest=refs.identity_lineage.evidence.digest,
            subject_digest=refs.identity_lineage.binding_digest,
        ),
        ControlDecisionRecord(
            role=ControlRole.PROVENANCE,
            decision_id=refs.provenance.decision_id,
            state=refs.provenance.state.value,
            policy_version=refs.provenance.policy_version,
            evidence_digest=refs.provenance.evidence.digest,
        ),
        ControlDecisionRecord(
            role=ControlRole.CONSENT,
            decision_id=refs.consent.decision_id,
            state=refs.consent.state.value,
            policy_version=refs.consent.policy_version,
            evidence_digest=refs.consent.evidence.digest,
        ),
        ControlDecisionRecord(
            role=ControlRole.QUALITY,
            decision_id=refs.quality.decision_id,
            state=refs.quality.state.value,
            policy_version=refs.quality.policy_version,
            evidence_digest=refs.quality.evidence.digest,
        ),
        ControlDecisionRecord(
            role=ControlRole.SUPPORT,
            decision_id=refs.support.decision_id,
            state=refs.support.state.value,
            policy_version=refs.support.policy_version,
            evidence_digest=refs.support.evidence.digest,
        ),
        ControlDecisionRecord(
            role=ControlRole.INTENDED_USE,
            decision_id=refs.intended_use.decision_id,
            state=refs.intended_use.state.value,
            policy_version=refs.intended_use.policy_version,
            evidence_digest=refs.intended_use.evidence.digest,
        ),
    )
    return ProvenanceRecord(
        activity_id=f"activity.{request.request_id}",
        actor_id=request.context.actor_id,
        module_id=M1106_MODULE_ID,
        module_version=M1106_CONTRACT_VERSION,
        generated_at=request.context.occurred_at,
        input_digests=(request_digest, request.upstream_result.digest),
        configuration_digest=request.configuration.reference_artifact.digest,
        consent_decision_id=refs.consent.decision_id,
        consent_state=refs.consent.state,
        consent_policy_version=refs.consent.policy_version,
        consent_evidence_digest=refs.consent.evidence.digest,
        control_decisions=controls,
    )


__all__ = [
    "M1106_CONTRACT_VERSION",
    "M1106_DEFAULT_BOOTSTRAP_REPLICATES",
    "M1106_EVIDENCE_CLAIM",
    "M1106_GATE",
    "M1106_M1105_INPUT_MEDIA_TYPE",
    "M1106_MAX_BOOTSTRAP_REPLICATES",
    "M1106_MAX_CANONICAL_REQUEST_BYTES",
    "M1106_MAX_CANONICAL_RESULT_BYTES",
    "M1106_MAX_DIAGNOSTICS",
    "M1106_MAX_EVIDENCE",
    "M1106_MAX_FINDINGS",
    "M1106_MAX_REPLICATES",
    "M1106_MAX_RESPONSES",
    "M1106_MAX_SCENARIOS",
    "M1106_MAX_TARGETS",
    "M1106_MINIMUM_REPLICATES_PER_ARM",
    "M1106_MODULE_ID",
    "M1106_OPERATION",
    "M1106_OUTPUT_MEDIA_TYPE",
    "M1106_OWNER",
    "M1106_PARENT",
    "M1106_PROVISIONAL_ABI",
    "M1106_SAFETY_CLASS",
    "PerturbationKind",
    "PerturbationResponseStatus",
    "PerturbationSpecification",
    "SensitivityDiagnostic",
    "SensitivityDiagnosticStatus",
    "SensitivityFindingCode",
    "SensitivityResponse",
    "SensitivitySimulationConfiguration",
    "SensitivitySimulationStatus",
    "SensitivitySurface",
    "SimulateVariantPeptidePerturbationsRequest",
    "VariantPeptideSensitivitySimulationResult",
    "expected_provenance",
    "expected_uncertainty",
]
