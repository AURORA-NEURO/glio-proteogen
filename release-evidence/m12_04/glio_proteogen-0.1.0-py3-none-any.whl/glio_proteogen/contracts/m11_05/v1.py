"""Provisional M11-05 longitudinal/evolutionary model contracts.

The M11-05 dossier specifies a time-indexed trajectory and explicit change-point
object.  Its public ABI is not yet frozen, so this contract is deliberately
marked provisional while preserving the safety boundary: ordered observations,
future-leakage checks, uncertainty, evidence, and safe abstention.
"""

from __future__ import annotations

from enum import StrEnum
from math import isfinite
from typing import Final, Literal

from pydantic import AwareDatetime, Field, model_validator

from glio_proteogen.contracts.m11_05.canonical import (
    canonical_request_digest,
    result_payload_digest,
)
from glio_proteogen.kernel.canonical import sha256_digest
from glio_proteogen.kernel.models import (
    ArtifactReference,
    ControlDecisionRecord,
    ControlRole,
    EstimateState,
    EvidenceReference,
    ExecutionContext,
    FrozenModel,
    Identifier,
    IdentityLineageReference,
    Limitation,
    NonEmptyStr,
    ProvenanceRecord,
    SemanticVersion,
    Sha256Digest,
    SupportDecision,
    SupportStatus,
    UncertaintyEstimate,
    UncertaintyProfile,
)

# PROVISIONAL ABI: inferred solely from dossier lines 3812-3855.
M1105_MODULE_ID: Final = "GLIO-PROTEOGEN-M11-05"
M1105_OPERATION: Final = "infer_variant_peptide_longitudinal_evolution"
M1105_CONTRACT_VERSION: Final = "0.1.0-provisional"
M1105_OUTPUT_MEDIA_TYPE: Final = "application/vnd.glio-proteogen.m11-05+json"
M1105_M1104_RESULT_MEDIA_TYPE: Final = "application/vnd.glio-proteogen.m11-04+json"
M1105_PARENT: Final = "variant_peptide"
M1105_OWNER: Final = "Data engineering"
M1105_SAFETY_CLASS: Final = "S2"
M1105_GATE: Final = "G2"
M1105_PROVISIONAL_ABI: Final = True
M1105_MAX_OBSERVATIONS: Final = 256
M1105_MAX_STATES: Final = 256
M1105_MAX_CHANGE_POINTS: Final = 128
M1105_MAX_EVIDENCE: Final = 64
M1105_MAX_DIAGNOSTICS: Final = 64
M1105_MAX_DIMENSIONS: Final = 16
M1105_MAX_CANONICAL_REQUEST_BYTES: Final = 4 * 1024 * 1024
M1105_MAX_CANONICAL_RESULT_BYTES: Final = 8 * 1024 * 1024
M1105_EVIDENCE_CLAIM: Final = (
    "Caller-declared longitudinal and evolutionary evidence; issuer authority is not "
    "authenticated by this provisional module."
)


class TrajectoryDimension(StrEnum):
    TIME_COURSE = "time_course"
    PRIMARY_RECURRENCE = "primary_recurrence"
    TREATMENT_ERA = "treatment_era"
    CLONE = "clone"
    TERRITORY = "territory"
    STATE_TRANSITION = "state_transition"


class EvolutionModelFamily(StrEnum):
    BAYESIAN_GRAPH = "bayesian_graph"
    STATE_SPACE = "state_space"
    MECHANISTIC = "mechanistic"
    FOUNDATION_ASSISTED = "foundation_assisted"
    MIXTURE_OF_EXPERTS = "mixture_of_experts"


class TrajectoryStatus(StrEnum):
    MODELED = "modeled"
    NOT_EVALUABLE = "not_evaluable"
    ABSTAINED = "abstained"


class LongitudinalObservationState(StrEnum):
    """Measurement state for a typed proteoform/variant-peptide time point."""

    OBSERVED = "observed"
    LEFT_CENSORED = "left_censored"
    MISSING = "missing"
    UNSUPPORTED = "unsupported"


class ChangePointStatus(StrEnum):
    DETECTED = "detected"
    NOT_DETECTED = "not_detected"
    NOT_EVALUABLE = "not_evaluable"


class LongitudinalDiagnosticCode(StrEnum):
    FUTURE_LEAKAGE_BLOCKED = "future_leakage_blocked"
    TEMPORAL_ORDERING_VERIFIED = "temporal_ordering_verified"
    INSUFFICIENT_HISTORY = "insufficient_history"
    UPSTREAM_UNSUPPORTED = "upstream_unsupported"
    PROVISIONAL_ABI_PENDING_REVIEW = "provisional_abi_pending_review"


class TimePointObservation(FrozenModel):
    """One immutable, ordered observation used by the longitudinal model.

    ``feature_artifact`` remains the immutable lineage handle.  The optional
    typed measurement fields make the computational lane usable without
    dereferencing arbitrary payloads: values are standardized proteomic
    effects (log2 fold-change relative to the subject's baseline), with assay
    uncertainty and an explicit censoring/missingness state.
    """

    observation_id: Identifier
    sequence: int = Field(ge=0, le=M1105_MAX_OBSERVATIONS)
    observed_at: AwareDatetime
    territory: NonEmptyStr
    treatment_era: NonEmptyStr
    feature_artifact: ArtifactReference
    measurement_state: LongitudinalObservationState = LongitudinalObservationState.UNSUPPORTED
    effect: float | None = Field(default=None, ge=-100.0, le=100.0)
    standard_error: float | None = Field(default=None, gt=0.0, le=100.0)
    quality_weight: float = Field(default=1.0, ge=0.0, le=1.0)
    censoring_limit: float | None = Field(default=None, ge=-100.0, le=100.0)
    evidence: tuple[EvidenceReference, ...] = Field(default=(), max_length=M1105_MAX_EVIDENCE)

    @model_validator(mode="after")
    def measurement_shape_is_closed(self) -> TimePointObservation:
        numeric = (self.effect, self.standard_error, self.quality_weight, self.censoring_limit)
        if any(number is not None and not isfinite(number) for number in numeric):
            raise ValueError("longitudinal measurements must contain finite numbers")
        if self.measurement_state is LongitudinalObservationState.OBSERVED:
            if (
                self.effect is None
                or self.standard_error is None
                or self.censoring_limit is not None
            ):
                raise ValueError("observed measurement requires effect and standard error only")
        elif self.measurement_state is LongitudinalObservationState.LEFT_CENSORED:
            if self.effect is not None or self.censoring_limit is None:
                raise ValueError(
                    "left-censored measurement requires a censoring limit and no effect"
                )
        elif (
            self.effect is not None
            or self.standard_error is not None
            or self.censoring_limit is not None
        ):
            raise ValueError("missing or unsupported measurement cannot carry numeric values")
        return self


class EvolutionModelConfiguration(FrozenModel):
    configuration_id: Identifier
    version: SemanticVersion
    model_family: EvolutionModelFamily
    objective: NonEmptyStr
    model_reference: ArtifactReference
    locked: Literal[True] = True
    future_leakage_blocked: Literal[True] = True
    evidence: tuple[EvidenceReference, ...] = Field(default=(), max_length=M1105_MAX_EVIDENCE)


class TrajectoryPolicy(FrozenModel):
    dimensions: tuple[TrajectoryDimension, ...] = Field(
        min_length=1, max_length=M1105_MAX_DIMENSIONS
    )
    minimum_observations: int = Field(ge=2, le=M1105_MAX_OBSERVATIONS)
    ordered_observations_required: Literal[True] = True
    future_leakage_blocked: Literal[True] = True
    configuration: EvolutionModelConfiguration

    @model_validator(mode="after")
    def dimensions_are_unique(self) -> TrajectoryPolicy:
        if len(set(self.dimensions)) != len(self.dimensions):
            raise ValueError("trajectory dimensions must be unique")
        return self


class TrajectoryState(FrozenModel):
    state_id: Identifier
    sequence: int = Field(ge=0, le=M1105_MAX_STATES)
    label: NonEmptyStr
    posterior_probability: float = Field(ge=0.0, le=1.0)
    observation_ids: tuple[Identifier, ...] = Field(min_length=1, max_length=M1105_MAX_OBSERVATIONS)
    evidence: tuple[EvidenceReference, ...] = Field(min_length=1, max_length=M1105_MAX_EVIDENCE)
    effect_estimate: float | None = Field(default=None, ge=-100.0, le=100.0)
    effect_lower: float | None = Field(default=None, ge=-100.0, le=100.0)
    effect_upper: float | None = Field(default=None, ge=-100.0, le=100.0)
    measurement_count: int = Field(default=0, ge=0, le=M1105_MAX_OBSERVATIONS)

    @model_validator(mode="after")
    def effect_interval_is_closed(self) -> TrajectoryState:
        numeric = (self.effect_estimate, self.effect_lower, self.effect_upper)
        if any(number is not None and not isfinite(number) for number in numeric):
            raise ValueError("trajectory effect interval must contain finite numbers")
        if (self.effect_lower is None) != (self.effect_upper is None):
            raise ValueError("trajectory effect interval requires both bounds")
        if (
            self.effect_lower is not None
            and self.effect_upper is not None
            and self.effect_lower > self.effect_upper
        ):
            raise ValueError("trajectory effect interval bounds must be ordered")
        if self.effect_estimate is None and self.measurement_count:
            raise ValueError("measured trajectory state requires an effect estimate")
        return self


class ChangePoint(FrozenModel):
    change_point_id: Identifier
    sequence: int = Field(ge=1, le=M1105_MAX_OBSERVATIONS)
    status: ChangePointStatus
    before_state_id: Identifier | None = None
    after_state_id: Identifier | None = None
    posterior_probability: float | None = Field(default=None, ge=0.0, le=1.0)
    rationale: NonEmptyStr
    evidence: tuple[EvidenceReference, ...] = Field(default=(), max_length=M1105_MAX_EVIDENCE)

    @model_validator(mode="after")
    def detected_shape_is_closed(self) -> ChangePoint:
        if self.status is ChangePointStatus.DETECTED:
            if (
                self.before_state_id is None
                or self.after_state_id is None
                or self.posterior_probability is None
                or not self.evidence
            ):
                raise ValueError("detected change point requires states, posterior, and evidence")
        elif any(
            value is not None
            for value in (self.before_state_id, self.after_state_id, self.posterior_probability)
        ):
            raise ValueError("non-detected change point cannot carry detected fields")
        return self


class LongitudinalDiagnostic(FrozenModel):
    diagnostic_id: Identifier
    code: LongitudinalDiagnosticCode
    message: NonEmptyStr
    evidence: tuple[EvidenceReference, ...] = Field(default=(), max_length=M1105_MAX_EVIDENCE)


class ModelVariantPeptideLongitudinalEvolutionRequest(FrozenModel):
    """Provisional request bound to the M11-04 mechanism/state result."""

    operation: Literal["infer_variant_peptide_longitudinal_evolution"] = M1105_OPERATION
    contract_version: Literal["0.1.0-provisional"] = M1105_CONTRACT_VERSION
    request_id: Identifier
    context: ExecutionContext
    network_state_result: ArtifactReference
    policy: TrajectoryPolicy
    observations: tuple[TimePointObservation, ...] = Field(
        min_length=2, max_length=M1105_MAX_OBSERVATIONS
    )
    source_artifacts: tuple[ArtifactReference, ...] = Field(
        min_length=1, max_length=M1105_MAX_EVIDENCE
    )
    supersedes_result_digest: Sha256Digest | None = None

    @model_validator(mode="after")
    def request_is_temporally_closed(self) -> ModelVariantPeptideLongitudinalEvolutionRequest:
        if self.network_state_result.media_type != M1105_M1104_RESULT_MEDIA_TYPE:
            raise ValueError("longitudinal request must bind the provisional M11-04 result")
        ids = tuple(item.observation_id for item in self.observations)
        if len(set(ids)) != len(ids):
            raise ValueError("observation identifiers must be unique")
        sequences = tuple(item.sequence for item in self.observations)
        if sequences != tuple(sorted(sequences)) or len(set(sequences)) != len(sequences):
            raise ValueError("observations must be strictly ordered by sequence")
        times = tuple(item.observed_at for item in self.observations)
        if times != tuple(sorted(times)) or len(set(times)) != len(times):
            raise ValueError("observations must be strictly ordered by observed_at")
        if len(self.observations) < self.policy.minimum_observations:
            raise ValueError("history does not meet the configured minimum")
        return self


class VariantPeptideLongitudinalEvolutionResult(FrozenModel):
    """Time-indexed trajectory with explicit change points and safe abstention."""

    output_type: Literal["variant_peptide_longitudinal_evolution"] = (
        "variant_peptide_longitudinal_evolution"
    )
    result_id: Identifier
    result_version: Literal["0.1.0-provisional"] = M1105_CONTRACT_VERSION
    request_digest: Sha256Digest
    result_digest: Sha256Digest
    request: ModelVariantPeptideLongitudinalEvolutionRequest
    status: TrajectoryStatus
    trajectory: tuple[TrajectoryState, ...] = Field(default=(), max_length=M1105_MAX_STATES)
    change_points: tuple[ChangePoint, ...] = Field(default=(), max_length=M1105_MAX_CHANGE_POINTS)
    diagnostics: tuple[LongitudinalDiagnostic, ...] = Field(
        default=(), max_length=M1105_MAX_DIAGNOSTICS
    )
    abstention_reason: NonEmptyStr | None = None
    parent_target: Literal["variant_peptide"] = M1105_PARENT
    emits_parent: Literal[False] = False
    support_decision: SupportDecision
    uncertainty: UncertaintyProfile
    provenance: ProvenanceRecord
    evidence: tuple[EvidenceReference, ...] = Field(default=(), max_length=M1105_MAX_EVIDENCE)
    limitations: tuple[Limitation, ...] = Field(min_length=1, max_length=32)
    temporal_order_verified: Literal[True] = True
    future_leakage_checked: Literal[True] = True
    human_review_required: bool = False

    @model_validator(mode="after")
    def result_is_closed(self) -> VariantPeptideLongitudinalEvolutionResult:
        if self.request_digest != canonical_request_digest(self.request):
            raise ValueError("result request digest does not bind the exact request")
        if self.status is TrajectoryStatus.MODELED:
            if (
                not self.trajectory
                or self.abstention_reason is not None
                or self.support_decision.status is not SupportStatus.SUPPORTED
            ):
                raise ValueError("modeled result requires a supported trajectory")
        elif (
            self.trajectory
            or self.change_points
            or self.abstention_reason is None
            or self.support_decision.status
            not in {SupportStatus.UNSUPPORTED, SupportStatus.REVIEW_REQUIRED}
        ):
            raise ValueError("abstained result requires no trajectory and safe status")
        state_ids = tuple(state.state_id for state in self.trajectory)
        if len(set(state_ids)) != len(state_ids):
            raise ValueError("trajectory state identifiers must be unique")
        change_point_ids = tuple(item.change_point_id for item in self.change_points)
        if len(set(change_point_ids)) != len(change_point_ids):
            raise ValueError("change-point identifiers must be unique")
        diagnostic_ids = tuple(item.diagnostic_id for item in self.diagnostics)
        if len(set(diagnostic_ids)) != len(diagnostic_ids):
            raise ValueError("diagnostic identifiers must be unique")
        state_sequences = tuple(state.sequence for state in self.trajectory)
        if state_sequences != tuple(sorted(state_sequences)):
            raise ValueError("trajectory states must be ordered")
        if len(self.change_points) > len(self.request.observations):
            raise ValueError("change-point count exceeds observation history")
        if self.result_digest != result_payload_digest(self):
            raise ValueError("result digest does not match canonical result content")
        return self


def _uncertainty_estimate(
    probability: float | None,
    rationale: str,
) -> UncertaintyEstimate:
    if probability is None:
        return UncertaintyEstimate(state=EstimateState.NOT_ESTIMABLE, rationale=rationale)
    return UncertaintyEstimate(
        state=EstimateState.ESTIMATED,
        probability=probability,
        rationale=rationale,
    )


def expected_uncertainty(*, supported: bool, measured: bool = False) -> UncertaintyProfile:
    """Return the fixed seven-dimension uncertainty envelope for M11-05."""

    probability = 0.9 if supported else None
    rationale = (
        (
            "Robust weighted trajectory fit with deterministic change-point scoring; "
            "external calibration is pending."
            if measured
            else "Deterministic provisional trajectory baseline; calibrated uncertainty is pending."
        )
        if supported
        else "Trajectory uncertainty is not estimable after safe abstention."
    )
    return UncertaintyProfile(
        measurement=_uncertainty_estimate(probability, rationale),
        sampling=_uncertainty_estimate(probability, rationale),
        parameter=_uncertainty_estimate(probability, rationale),
        model_form=_uncertainty_estimate(probability, rationale),
        identification=_uncertainty_estimate(probability, rationale),
        support=_uncertainty_estimate(probability, rationale),
        transport=_uncertainty_estimate(probability, rationale),
        sensitivity_notes=(
            "Temporal ordering and future-leakage gates are deterministic.",
            "Feature artifacts are opaque references and are never traversed.",
        ),
    )


def expected_provenance(
    request: ModelVariantPeptideLongitudinalEvolutionRequest,
    request_hash: Sha256Digest,
) -> ProvenanceRecord:
    """Derive auditable provenance only from caller-declared references."""

    refs = request.context.references
    controls = (
        (ControlRole.APPROVED_CONFIGURATION, refs.approved_configuration),
        (ControlRole.IDENTITY_LINEAGE, refs.identity_lineage),
        (ControlRole.PROVENANCE, refs.provenance),
        (ControlRole.CONSENT, refs.consent),
        (ControlRole.QUALITY, refs.quality),
        (ControlRole.SUPPORT, refs.support),
        (ControlRole.INTENDED_USE, refs.intended_use),
    )
    decisions = tuple(
        ControlDecisionRecord(
            role=role,
            decision_id=decision.decision_id,
            state=decision.state.value,
            policy_version=decision.policy_version,
            evidence_digest=decision.evidence.digest,
            subject_digest=(
                decision.binding_digest if isinstance(decision, IdentityLineageReference) else None
            ),
        )
        for role, decision in controls
    )
    input_digests = (
        request.network_state_result.digest,
        *(artifact.digest for artifact in request.source_artifacts),
        *(observation.feature_artifact.digest for observation in request.observations),
    )
    return ProvenanceRecord(
        activity_id=f"activity.{request_hash.removeprefix('sha256:')[:32]}",
        actor_id=request.context.actor_id,
        module_id=M1105_MODULE_ID,
        module_version=M1105_CONTRACT_VERSION,
        generated_at=request.context.occurred_at,
        input_digests=input_digests,
        configuration_digest=sha256_digest(request.policy.configuration.model_dump(mode="json")),
        consent_decision_id=refs.consent.decision_id,
        consent_state=refs.consent.state,
        consent_policy_version=refs.consent.policy_version,
        consent_evidence_digest=refs.consent.evidence.digest,
        control_decisions=decisions,
    )


__all__ = [
    "M1105_CONTRACT_VERSION",
    "M1105_EVIDENCE_CLAIM",
    "M1105_GATE",
    "M1105_M1104_RESULT_MEDIA_TYPE",
    "M1105_MAX_CANONICAL_REQUEST_BYTES",
    "M1105_MAX_CANONICAL_RESULT_BYTES",
    "M1105_MAX_CHANGE_POINTS",
    "M1105_MAX_DIAGNOSTICS",
    "M1105_MAX_DIMENSIONS",
    "M1105_MAX_EVIDENCE",
    "M1105_MAX_OBSERVATIONS",
    "M1105_MAX_STATES",
    "M1105_MODULE_ID",
    "M1105_OPERATION",
    "M1105_OUTPUT_MEDIA_TYPE",
    "M1105_OWNER",
    "M1105_PARENT",
    "M1105_PROVISIONAL_ABI",
    "M1105_SAFETY_CLASS",
    "ChangePoint",
    "ChangePointStatus",
    "EvolutionModelConfiguration",
    "EvolutionModelFamily",
    "LongitudinalDiagnostic",
    "LongitudinalDiagnosticCode",
    "LongitudinalObservationState",
    "ModelVariantPeptideLongitudinalEvolutionRequest",
    "TimePointObservation",
    "TrajectoryDimension",
    "TrajectoryPolicy",
    "TrajectoryState",
    "TrajectoryStatus",
    "VariantPeptideLongitudinalEvolutionResult",
    "expected_provenance",
    "expected_uncertainty",
]
