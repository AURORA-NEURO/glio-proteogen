"""Provisional M12-04 network/state/mechanism inference contracts.

The M12-04 dossier requires a mechanism posterior or state estimate with
explicit assumptions, alternatives, counter-evidence, typed uncertainty, and
safe abstention.  The public ABI and handoff details are not frozen; all
symbols are provisional pending Clinical science owner confirmation.
"""

from __future__ import annotations

from enum import StrEnum
from typing import Final, Literal

from pydantic import Field, model_validator

from glio_proteogen.contracts.m12_04.canonical import (
    canonical_request_digest,
    result_payload_digest,
)
from glio_proteogen.kernel.models import (
    ArtifactReference,
    ControlDecisionRecord,
    ControlRole,
    EstimateState,
    EvidenceReference,
    ExecutionContext,
    FrozenModel,
    Identifier,
    Limitation,
    NonEmptyStr,
    ProvenanceRecord,
    SemanticVersion,
    Sha256Digest,
    SupportDecision,
    SupportStatus,
    UncertaintyEstimate,
    UncertaintyProfile,
)

# PROVISIONAL ABI: inferred solely from the M12-04 dossier slice.
M1204_MODULE_ID: Final = "GLIO-PROTEOGEN-M12-04"
M1204_OPERATION: Final = "infer_biomarker_panel_mechanism"
M1204_CONTRACT_VERSION: Final = "0.1.0-provisional"
M1204_OUTPUT_MEDIA_TYPE: Final = "application/vnd.glio-proteogen.m12-04+json"
M1204_M1201_RESULT_MEDIA_TYPE: Final = "application/vnd.glio-proteogen.m12-01+json"
M1204_PARENT: Final = "biomarker_panel"
M1204_OWNER: Final = "Data engineering"
M1204_SAFETY_CLASS: Final = "S2"
M1204_GATE: Final = "G2"
M1204_PROVISIONAL_ABI: Final = True
M1204_MAX_ESTIMATES: Final = 512
M1204_MAX_ASSUMPTIONS: Final = 64
M1204_MAX_ALTERNATIVES: Final = 64
M1204_MAX_EVIDENCE: Final = 64
M1204_MAX_FINDINGS: Final = 64
M1204_MAX_CANONICAL_REQUEST_BYTES: Final = 4 * 1024 * 1024
M1204_MAX_CANONICAL_RESULT_BYTES: Final = 8 * 1024 * 1024
M1204_EVIDENCE_CLAIM: Final = (
    "Caller-declared M12-01 hypothesis and M12-04 mechanism-inference evidence; "
    "issuer authority is not authenticated."
)


class MechanismEstimateKind(StrEnum):
    POSTERIOR = "posterior"
    STATE = "state"


class MechanismInferenceStatus(StrEnum):
    INFERRED = "inferred"
    ABSTAINED = "abstained"


class MechanismFindingCode(StrEnum):
    UPSTREAM_UNSUPPORTED = "upstream_unsupported"
    COUNTER_EVIDENCE_REQUIRED = "counter_evidence_required"
    MODEL_NOT_CALIBRATED = "model_not_calibrated"
    PROVISIONAL_ABI_PENDING_REVIEW = "provisional_abi_pending_review"


class MechanismInferenceConfiguration(FrozenModel):
    configuration_id: Identifier
    version: SemanticVersion
    method: NonEmptyStr
    model_reference: ArtifactReference
    calibration_reference: ArtifactReference
    locked: Literal[True] = True
    evidence: tuple[EvidenceReference, ...] = Field(default=(), max_length=M1204_MAX_EVIDENCE)


class MechanismEstimate(FrozenModel):
    """Posterior or state estimate with explicit counter-evidence."""

    estimate_id: Identifier
    mechanism_id: Identifier
    label: NonEmptyStr
    kind: MechanismEstimateKind
    posterior_probability: float | None = Field(default=None, ge=0.0, le=1.0)
    lower_bound: float | None = Field(default=None, ge=0.0, le=1.0)
    upper_bound: float | None = Field(default=None, ge=0.0, le=1.0)
    state_value: NonEmptyStr | None = None
    assumptions: tuple[NonEmptyStr, ...] = Field(min_length=1, max_length=M1204_MAX_ASSUMPTIONS)
    alternatives: tuple[NonEmptyStr, ...] = Field(min_length=1, max_length=M1204_MAX_ALTERNATIVES)
    counter_evidence: tuple[EvidenceReference, ...] = Field(
        min_length=1, max_length=M1204_MAX_EVIDENCE
    )
    evidence: tuple[EvidenceReference, ...] = Field(default=(), max_length=M1204_MAX_EVIDENCE)

    @model_validator(mode="after")
    def estimate_shape_is_closed(self) -> MechanismEstimate:
        has_interval = self.lower_bound is not None or self.upper_bound is not None
        if self.kind is MechanismEstimateKind.POSTERIOR:
            if (
                self.posterior_probability is None
                or self.lower_bound is None
                or self.upper_bound is None
                or self.lower_bound > self.upper_bound
                or not self.lower_bound <= self.posterior_probability <= self.upper_bound
                or self.state_value is not None
            ):
                raise ValueError("posterior estimate requires ordered bounds and probability")
        elif self.state_value is None or self.posterior_probability is not None or has_interval:
            raise ValueError("state estimate requires state value without posterior bounds")
        return self


class MechanismFinding(FrozenModel):
    finding_id: Identifier
    code: MechanismFindingCode
    message: NonEmptyStr
    evidence: tuple[EvidenceReference, ...] = Field(default=(), max_length=M1204_MAX_EVIDENCE)


class InferBiomarkerPanelMechanismRequest(FrozenModel):
    """Provisional request bound to the M12-01 hypothesis registry."""

    operation: Literal["infer_biomarker_panel_mechanism"] = M1204_OPERATION
    contract_version: Literal["0.1.0-provisional"] = M1204_CONTRACT_VERSION
    request_id: Identifier
    context: ExecutionContext
    hypothesis_registry_result: ArtifactReference
    configuration: MechanismInferenceConfiguration
    source_artifacts: tuple[ArtifactReference, ...] = Field(
        min_length=1, max_length=M1204_MAX_EVIDENCE
    )
    supersedes_result_digest: Sha256Digest | None = None

    @model_validator(mode="after")
    def request_is_bound(self) -> InferBiomarkerPanelMechanismRequest:
        if self.hypothesis_registry_result.media_type != M1204_M1201_RESULT_MEDIA_TYPE:
            raise ValueError("mechanism request must bind the provisional M12-01 result")
        return self


class BiomarkerPanelMechanismInferenceResult(FrozenModel):
    """Mechanism estimates with counter-evidence and explicit abstention."""

    output_type: Literal["biomarker_panel_mechanism_inference"] = (
        "biomarker_panel_mechanism_inference"
    )
    result_id: Identifier
    result_version: Literal["0.1.0-provisional"] = M1204_CONTRACT_VERSION
    request_digest: Sha256Digest
    result_digest: Sha256Digest
    request: InferBiomarkerPanelMechanismRequest
    status: MechanismInferenceStatus
    estimates: tuple[MechanismEstimate, ...] = Field(default=(), max_length=M1204_MAX_ESTIMATES)
    findings: tuple[MechanismFinding, ...] = Field(default=(), max_length=M1204_MAX_FINDINGS)
    abstention_reason: NonEmptyStr | None = None
    parent_target: Literal["biomarker_panel"] = M1204_PARENT
    emits_parent: Literal[False] = False
    support_decision: SupportDecision
    uncertainty: UncertaintyProfile
    provenance: ProvenanceRecord
    evidence: tuple[EvidenceReference, ...] = Field(default=(), max_length=M1204_MAX_EVIDENCE)
    limitations: tuple[Limitation, ...] = Field(min_length=1, max_length=32)
    human_review_required: bool = False

    @model_validator(mode="after")
    def result_is_closed(self) -> BiomarkerPanelMechanismInferenceResult:
        if self.request_digest != canonical_request_digest(self.request):
            raise ValueError("result request digest does not bind the exact request")
        expected_result_id = f"result.{self.request_digest.removeprefix('sha256:')}"
        if self.result_id != expected_result_id:
            raise ValueError("result identifier must be derived from request digest")
        estimate_ids = tuple(item.estimate_id for item in self.estimates)
        if len(estimate_ids) != len(set(estimate_ids)):
            raise ValueError("estimate ids must be unique")
        finding_ids = tuple(item.finding_id for item in self.findings)
        if len(finding_ids) != len(set(finding_ids)):
            raise ValueError("finding ids must be unique")
        if not self.evidence or any(item.role != "evidence" for item in self.evidence):
            raise ValueError("every result requires evidence references with the evidence role")
        if self.status is MechanismInferenceStatus.INFERRED:
            if (
                not self.estimates
                or self.abstention_reason is not None
                or self.support_decision.status is not SupportStatus.SUPPORTED
                or self.human_review_required
            ):
                raise ValueError("inferred result requires supported mechanism estimates")
        elif (
            self.estimates
            or self.abstention_reason is None
            or self.support_decision.status
            not in {SupportStatus.UNSUPPORTED, SupportStatus.REVIEW_REQUIRED}
            or not self.human_review_required
        ):
            raise ValueError("abstained result requires no estimates and safe status")
        if self.result_digest != result_payload_digest(self):
            raise ValueError("result digest does not match canonical result content")
        return self


def expected_uncertainty(*, supported: bool) -> UncertaintyProfile:
    """Construct all seven uncertainty dimensions without hiding abstention."""

    estimate = UncertaintyEstimate(
        state=EstimateState.ESTIMATED if supported else EstimateState.NOT_ESTIMABLE,
        probability=0.9 if supported else None,
        rationale=(
            "Closed mechanism evidence and calibration references are present; population "
            "coverage is not inferred from a single request."
            if supported
            else "Mechanism evidence, quality, or upstream support was not safely evaluable."
        ),
    )
    return UncertaintyProfile(
        measurement=estimate,
        sampling=estimate,
        parameter=estimate,
        model_form=estimate,
        identification=estimate,
        support=estimate,
        transport=estimate,
        sensitivity_notes=(
            "Assumptions, alternatives, counter-evidence, and sensitivity are retained.",
            "Unsupported or missing evidence is never converted into a negative mechanism.",
        ),
    )


def expected_provenance(
    request: InferBiomarkerPanelMechanismRequest,
    request_digest: Sha256Digest,
) -> ProvenanceRecord:
    """Project the seven caller-declared controls into auditable provenance."""

    refs = request.context.references
    decisions = (
        ControlDecisionRecord(
            role=ControlRole.APPROVED_CONFIGURATION,
            decision_id=refs.approved_configuration.decision_id,
            state=refs.approved_configuration.state.value,
            policy_version=refs.approved_configuration.policy_version,
            evidence_digest=refs.approved_configuration.evidence.digest,
        ),
        ControlDecisionRecord(
            role=ControlRole.IDENTITY_LINEAGE,
            decision_id=refs.identity_lineage.decision_id,
            state=refs.identity_lineage.state.value,
            policy_version=refs.identity_lineage.policy_version,
            evidence_digest=refs.identity_lineage.evidence.digest,
            subject_digest=refs.identity_lineage.binding_digest,
        ),
        ControlDecisionRecord(
            role=ControlRole.PROVENANCE,
            decision_id=refs.provenance.decision_id,
            state=refs.provenance.state.value,
            policy_version=refs.provenance.policy_version,
            evidence_digest=refs.provenance.evidence.digest,
        ),
        ControlDecisionRecord(
            role=ControlRole.CONSENT,
            decision_id=refs.consent.decision_id,
            state=refs.consent.state.value,
            policy_version=refs.consent.policy_version,
            evidence_digest=refs.consent.evidence.digest,
        ),
        ControlDecisionRecord(
            role=ControlRole.QUALITY,
            decision_id=refs.quality.decision_id,
            state=refs.quality.state.value,
            policy_version=refs.quality.policy_version,
            evidence_digest=refs.quality.evidence.digest,
        ),
        ControlDecisionRecord(
            role=ControlRole.SUPPORT,
            decision_id=refs.support.decision_id,
            state=refs.support.state.value,
            policy_version=refs.support.policy_version,
            evidence_digest=refs.support.evidence.digest,
        ),
        ControlDecisionRecord(
            role=ControlRole.INTENDED_USE,
            decision_id=refs.intended_use.decision_id,
            state=refs.intended_use.state.value,
            policy_version=refs.intended_use.policy_version,
            evidence_digest=refs.intended_use.evidence.digest,
        ),
    )
    return ProvenanceRecord(
        activity_id=f"activity.{request_digest.removeprefix('sha256:')}",
        actor_id=request.context.actor_id,
        module_id=M1204_MODULE_ID,
        module_version=M1204_CONTRACT_VERSION,
        generated_at=request.context.occurred_at,
        input_digests=(
            request_digest,
            request.hypothesis_registry_result.digest,
            *(artifact.digest for artifact in request.source_artifacts),
            *(item.evidence_digest for item in decisions),
        ),
        configuration_digest=refs.approved_configuration.evidence.digest,
        consent_decision_id=refs.consent.decision_id,
        consent_state=refs.consent.state,
        consent_policy_version=refs.consent.policy_version,
        consent_evidence_digest=refs.consent.evidence.digest,
        control_decisions=decisions,
    )


__all__ = [
    "M1204_CONTRACT_VERSION",
    "M1204_EVIDENCE_CLAIM",
    "M1204_GATE",
    "M1204_M1201_RESULT_MEDIA_TYPE",
    "M1204_MAX_ALTERNATIVES",
    "M1204_MAX_ASSUMPTIONS",
    "M1204_MAX_CANONICAL_REQUEST_BYTES",
    "M1204_MAX_CANONICAL_RESULT_BYTES",
    "M1204_MAX_ESTIMATES",
    "M1204_MAX_EVIDENCE",
    "M1204_MAX_FINDINGS",
    "M1204_MODULE_ID",
    "M1204_OPERATION",
    "M1204_OUTPUT_MEDIA_TYPE",
    "M1204_OWNER",
    "M1204_PARENT",
    "M1204_PROVISIONAL_ABI",
    "M1204_SAFETY_CLASS",
    "BiomarkerPanelMechanismInferenceResult",
    "InferBiomarkerPanelMechanismRequest",
    "MechanismEstimate",
    "MechanismEstimateKind",
    "MechanismFinding",
    "MechanismFindingCode",
    "MechanismInferenceConfiguration",
    "MechanismInferenceStatus",
    "expected_provenance",
    "expected_uncertainty",
]
