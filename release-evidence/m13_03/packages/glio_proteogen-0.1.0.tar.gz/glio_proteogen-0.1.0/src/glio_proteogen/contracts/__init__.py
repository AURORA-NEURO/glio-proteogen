"""Versioned public module contracts."""
