"""Executable module evidence gates."""
