"""Benchmark only public M04-03 ingestion on four genuine canonical manifests."""

from __future__ import annotations

import argparse
import gc
import json
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from statistics import fmean, median
from time import process_time_ns
from typing import Final

if __package__ in {None, ""}:
    _PROJECT_ROOT = Path(__file__).resolve().parents[2]
    if str(_PROJECT_ROOT) not in sys.path:
        sys.path.insert(0, str(_PROJECT_ROOT))

from evals.m04_03.run import build_scenario
from glio_proteogen.contracts.m04_03 import (
    M0403_LIMITATION_COUNT,
    M0403_MIN_EVIDENCE,
    M0403_MODULE_ID,
    M0403_ROLE_COUNT,
    ProteoformRawInputDisposition,
)
from glio_proteogen.modules.c04_proteoform_isoform.m04_03_raw_ingestion import (
    ingest_proteoform_raw_inputs,
)

# One hundred samples make nearest-rank p95 the 95th ordered observation rather
# than the second-slowest value from a 25-call run. This preserves the installed
# latency ceilings while preventing two isolated tail samples from defining p95.
ITERATIONS: Final = 100
WARMUP_COUNT: Final = 1
# The mean ceiling is calibrated to retain a 20% reserve below the unchanged
# p95 ceiling.  That separation catches sustained regressions without treating
# normal hosted-runner scheduling variance as a scientific-evidence failure.
MEAN_BUDGET_NS: Final = 625_000_000
P95_BUDGET_NS: Final = 750_000_000
MEASUREMENT_CLOCK: Final = "process_time_ns"


@dataclass(frozen=True, slots=True)
class BenchmarkReport:
    module_id: str
    contract_version: str
    workload: str
    timed_boundary: str
    measurement_clock: str
    iterations: int
    warmup_count: int
    input_artifact_count: int
    document_count: int
    validated_input_count: int
    diagnostic_count: int
    evidence_count: int
    limitation_count: int
    request_digest: str
    result_digest: str
    pre_timing_gc_collected_objects: int
    cyclic_gc_enabled_during_timing: bool
    mean_ns: float
    p50_ns: float
    p95_ns: int
    maximum_ns: int
    mean_budget_ns: int
    p95_budget_ns: int
    passed: bool


class InvalidRepresentativeWorkloadError(RuntimeError):
    """The public builder no longer supplies the frozen modest workload."""


class NonDeterministicBenchmarkError(RuntimeError):
    """A timed ingestion disagreed with the untimed warmup result."""


class InvalidBenchmarkEnvironmentError(RuntimeError):
    """The interpreter does not expose the benchmark's normal cyclic-GC policy."""


def run_benchmark(iterations: int = ITERATIONS) -> BenchmarkReport:
    """Build and warm outside timing, then time the bounded public workload."""

    if iterations < 1:
        raise ValueError("iterations must be positive")  # noqa: TRY003
    if not gc.isenabled():
        raise InvalidBenchmarkEnvironmentError
    scenario = build_scenario()
    warmup = ingest_proteoform_raw_inputs(scenario.request, scenario.artifacts_by_role)
    if (
        len(scenario.request.artifacts) != M0403_ROLE_COUNT
        or len(scenario.artifacts_by_role) != M0403_ROLE_COUNT
        or warmup.disposition is not ProteoformRawInputDisposition.VALIDATED
        or len(warmup.validated_inputs) != M0403_ROLE_COUNT
        or len(warmup.diagnostics) != 0
        or len(warmup.evidence) != M0403_MIN_EVIDENCE
        or len(warmup.limitations) != M0403_LIMITATION_COUNT
        or warmup.parent_target != "protein_rna_discordance"
    ):
        raise InvalidRepresentativeWorkloadError

    # Settle full-generation scan debt created by genuine upstream setup and
    # warm-up.  Cyclic GC stays enabled throughout every measured public call.
    pre_timing_gc_collected_objects = gc.collect()
    samples: list[int] = []
    for _ in range(iterations):
        started = process_time_ns()
        result = ingest_proteoform_raw_inputs(
            scenario.request,
            scenario.artifacts_by_role,
        )
        elapsed = process_time_ns() - started
        if result != warmup:
            raise NonDeterministicBenchmarkError
        samples.append(elapsed)

    ordered = sorted(samples)
    p95 = ordered[(95 * len(ordered) - 1) // 100]
    mean = fmean(samples)
    return BenchmarkReport(
        module_id=M0403_MODULE_ID,
        contract_version="1.0.0",
        workload="genuine_four_modest_canonical_raw_manifest_documents",
        timed_boundary="ingest_proteoform_raw_inputs_only",
        measurement_clock=MEASUREMENT_CLOCK,
        iterations=iterations,
        warmup_count=WARMUP_COUNT,
        input_artifact_count=len(scenario.request.artifacts),
        document_count=len(scenario.artifacts_by_role),
        validated_input_count=len(warmup.validated_inputs),
        diagnostic_count=len(warmup.diagnostics),
        evidence_count=len(warmup.evidence),
        limitation_count=len(warmup.limitations),
        request_digest=warmup.request_digest,
        result_digest=warmup.result_digest,
        pre_timing_gc_collected_objects=pre_timing_gc_collected_objects,
        cyclic_gc_enabled_during_timing=gc.isenabled(),
        mean_ns=mean,
        p50_ns=median(samples),
        p95_ns=p95,
        maximum_ns=max(samples),
        mean_budget_ns=MEAN_BUDGET_NS,
        p95_budget_ns=P95_BUDGET_NS,
        passed=gc.isenabled() and mean <= MEAN_BUDGET_NS and p95 <= P95_BUDGET_NS,
    )


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path)
    return parser


def main(argv: list[str] | None = None) -> int:
    arguments = _parser().parse_args(argv)
    report = run_benchmark()
    rendered = json.dumps(asdict(report), indent=2, sort_keys=True) + "\n"
    if arguments.output is None:
        sys.stdout.write(rendered)
    else:
        arguments.output.write_text(rendered, encoding="utf-8")
    return 0 if report.passed else 1


__all__ = [
    "BenchmarkReport",
    "InvalidBenchmarkEnvironmentError",
    "main",
    "run_benchmark",
]


if __name__ == "__main__":
    raise SystemExit(main())
