"""Executable evaluator for the provisional M06-08 evidence publisher.

The evaluator treats abstention as a first-class safe outcome.  It checks
the dossier's publication evidence closure, not just that a Python function
returns an object: controls are fail-closed, replay is transitive, malformed
JSON is rejected before validation, and a tampered receipt cannot verify.
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import UTC, datetime
from pathlib import Path
from typing import Final

from pydantic import ValidationError

if __package__ in {None, ""}:
    _PROJECT_ROOT = Path(__file__).resolve().parents[2]
    if str(_PROJECT_ROOT) not in sys.path:
        sys.path.insert(0, str(_PROJECT_ROOT))

from glio_proteogen.contracts.m06_08 import (
    M0608_M0607_RESULT_MEDIA_TYPE,
    EvidencePublicationStatus,
    ProteinAbundanceEvidencePublicationResult,
    PublisherAssumption,
    PublisherCounterEvidence,
    PublishProteinAbundanceEvidenceRequest,
    ReconstructionStep,
)
from glio_proteogen.contracts.m06_08.canonical import result_payload_digest
from glio_proteogen.kernel.models import (
    ArtifactReference,
    ConsentReference,
    ConsentState,
    ContextReferences,
    EvidenceReference,
    ExecutionContext,
    IdentityLineageReference,
    IdentityLineageState,
    UpstreamDecisionReference,
    UpstreamDecisionState,
)
from glio_proteogen.kernel.strict_json import StrictJsonError, strict_json_loads
from glio_proteogen.modules.c06_protein_abundance.m06_08_evidence_explanation_publisher import (
    M0608EvidencePublisherAuthorizationError,
    M0608ReplayVerificationError,
    M0608Service,
)

MODULE_ID: Final = "GLIO-PROTEOGEN-M06-08"
EVALUATOR_VERSION: Final = "0.1.0-provisional"
_DIGEST_FILL: Final = "a"


def _artifact(name: str, fill: str, media_type: str = "application/json") -> ArtifactReference:
    return ArtifactReference(
        artifact_id=f"{name}.{fill}",
        version="0.1.0",
        digest=f"sha256:{fill * 64}",
        media_type=media_type,
    )


def build_request(
    *, accepted_controls: bool = True, evidence_backed: bool = False
) -> PublishProteinAbundanceEvidenceRequest:
    """Build a representative request using only opaque artifact references."""

    state = UpstreamDecisionState.ACCEPTED if accepted_controls else UpstreamDecisionState.UNKNOWN
    consent_state = ConsentState.GRANTED if accepted_controls else ConsentState.UNKNOWN
    identity_state = (
        IdentityLineageState.RESOLVED if accepted_controls else IdentityLineageState.UNRESOLVED
    )
    upstream = _artifact("m0607.result", "1", M0608_M0607_RESULT_MEDIA_TYPE)
    source = _artifact("proteome.source", "2")
    positive_evidence = EvidenceReference(
        reference=source,
        role="evidence",
        claim="approved normalization evidence",
    )
    counter_evidence = EvidenceReference(
        reference=source,
        role="counter_evidence",
        claim="batch-effect counter-evidence",
    )
    return PublishProteinAbundanceEvidenceRequest(
        request_id="request.eval.m0608",
        context=ExecutionContext(
            request_id="request.eval.m0608",
            actor_id="actor.evaluator",
            occurred_at=datetime(2026, 1, 1, tzinfo=UTC),
            references=ContextReferences(
                approved_configuration=UpstreamDecisionReference(
                    decision_id="decision.config",
                    state=state,
                    policy_version="1.0.0",
                    evidence=_artifact("config", "3"),
                ),
                identity_lineage=IdentityLineageReference(
                    decision_id="decision.identity",
                    state=identity_state,
                    policy_version="1.0.0",
                    binding_digest=_artifact("identity", "4").digest,
                    evidence=_artifact("identity", "4"),
                ),
                provenance=UpstreamDecisionReference(
                    decision_id="decision.provenance",
                    state=state,
                    policy_version="1.0.0",
                    evidence=_artifact("provenance", "5"),
                ),
                consent=ConsentReference(
                    decision_id="decision.consent",
                    state=consent_state,
                    policy_version="1.0.0",
                    evidence=_artifact("consent", "6"),
                ),
                quality=UpstreamDecisionReference(
                    decision_id="decision.quality",
                    state=state,
                    policy_version="1.0.0",
                    evidence=_artifact("quality", "7"),
                ),
                support=UpstreamDecisionReference(
                    decision_id="decision.support",
                    state=state,
                    policy_version="1.0.0",
                    evidence=_artifact("support", "8"),
                ),
                intended_use=UpstreamDecisionReference(
                    decision_id="decision.intended",
                    state=state,
                    policy_version="1.0.0",
                    evidence=_artifact("intended", "9"),
                ),
            ),
        ),
        upstream_result=upstream,
        source_artifacts=(source,),
        assumptions=(
            PublisherAssumption(
                assumption_id="assumption.normalization",
                statement="Input intensity values use the approved normalized scale.",
                evidence=(positive_evidence,) if evidence_backed else (),
            ),
        ),
        counter_evidence=(
            PublisherCounterEvidence(
                counter_evidence_id="counter.batch",
                statement="A batch effect remains possible.",
                impact="The claim must remain reviewable.",
                evidence=(counter_evidence,) if evidence_backed else (),
            ),
        ),
        reconstruction_steps=(
            ReconstructionStep(
                sequence=1,
                operation="bind_upstream_result",
                input_digests=(upstream.digest, source.digest),
                output_digest=_artifact("reconstruction", "0").digest,
                evidence=(positive_evidence,) if evidence_backed else (),
            ),
        ),
    )


def _check(name: str, *, passed: bool, detail: str) -> dict[str, object]:
    return {"id": name, "passed": passed, "detail": detail}


def _check_self_rehashed_receipt(
    service: M0608Service,
    result: ProteinAbundanceEvidencePublicationResult,
) -> dict[str, object]:
    candidate = result.model_copy(update={"abstention_reason": "forged replay"})
    candidate = candidate.model_copy(update={"result_digest": result_payload_digest(candidate)})
    try:
        service.verify(candidate, replay=False)
    except M0608ReplayVerificationError:
        rejected = True
    else:
        rejected = False
    return _check(
        "self_rehashed_receipt_rejected_even_when_replay_disabled",
        passed=rejected,
        detail="the compatibility replay flag cannot downgrade to digest-only verification",
    )


def evaluate() -> dict[str, object]:
    service = M0608Service()
    request = build_request()
    result = service.execute(request)
    published = service.execute(build_request(evidence_backed=True))
    checks: list[dict[str, object]] = []
    checks.append(
        _check(
            "safe_abstention_has_required_evidence_closure",
            passed=result.status is EvidencePublicationStatus.ABSTAINED
            and result.bundle is None
            and result.explanation is None
            and bool(result.evidence)
            and result.human_review_required,
            detail=(
                "abstention carries evidence, typed support status, limitations, "
                "uncertainty, and review"
            ),
        )
    )
    checks.append(
        _check(
            "evidence_backed_bundle_is_published",
            passed=(
                published.status is EvidencePublicationStatus.PUBLISHED
                and published.bundle is not None
                and published.explanation is not None
                and published.support_decision.status.value == "supported"
                and not published.human_review_required
                and service.verify(published) == published
            ),
            detail="explicit evidence and digest-linked reconstruction produce a replayable bundle",
        )
    )
    replay = service.verify(result)
    checks.append(
        _check(
            "transitive_replay_is_byte_stable",
            passed=replay.model_dump_json() == result.model_dump_json(),
            detail="exact request replay reproduced the canonical result envelope",
        )
    )
    tampered = result.model_copy(update={"abstention_reason": "tampered"})
    try:
        service.verify(tampered)
    except M0608ReplayVerificationError:
        tamper_rejected = True
    else:
        tamper_rejected = False
    checks.append(
        _check(
            "tampered_receipt_rejected",
            passed=tamper_rejected,
            detail="changed abstention text cannot pass replay",
        )
    )
    checks.append(_check_self_rehashed_receipt(service, result))
    try:
        service.execute(build_request(accepted_controls=False))
    except M0608EvidencePublisherAuthorizationError:
        controls_fail_closed = True
    else:
        controls_fail_closed = False
    checks.append(
        _check(
            "unresolved_controls_fail_closed",
            passed=controls_fail_closed,
            detail="identity, consent, and upstream control states are never inferred",
        )
    )
    try:
        PublishProteinAbundanceEvidenceRequest.model_validate(
            request.model_dump(mode="python")
            | {"upstream_result": _artifact("wrong-upstream", _DIGEST_FILL)},
            strict=True,
        )
    except ValidationError:
        wrong_upstream_rejected = True
    else:
        wrong_upstream_rejected = False
    checks.append(
        _check(
            "wrong_upstream_media_rejected",
            passed=wrong_upstream_rejected,
            detail="M06-07 binding is explicit",
        )
    )
    try:
        strict_json_loads('{"request_id":"a","request_id":"b"}')
    except StrictJsonError:
        duplicate_rejected = True
    else:
        duplicate_rejected = False
    checks.append(
        _check(
            "duplicate_json_keys_rejected",
            passed=duplicate_rejected,
            detail="parse-once strict JSON rejects duplicates",
        )
    )
    checks.append(
        _check(
            "prohibited_parent_emission_is_false",
            passed=result.emits_parent is False and result.parent_target == "biomarker_panel",
            detail="publisher does not emit a biomarker panel or treatment recommendation",
        )
    )
    passed = all(item["passed"] is True for item in checks)
    return {
        "module_id": MODULE_ID,
        "evaluator_version": EVALUATOR_VERSION,
        "passed": passed,
        "checks": checks,
        "check_count": len(checks),
        "generated_at": "2026-01-01T00:00:00Z",
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path)
    arguments = parser.parse_args()
    report = evaluate()
    encoded = json.dumps(report, indent=2, sort_keys=True) + "\n"
    if arguments.output:
        arguments.output.parent.mkdir(parents=True, exist_ok=True)
        arguments.output.write_text(encoded, encoding="utf-8")
    else:
        sys.stdout.write(encoded)
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())


__all__ = ["build_request", "evaluate", "main"]
