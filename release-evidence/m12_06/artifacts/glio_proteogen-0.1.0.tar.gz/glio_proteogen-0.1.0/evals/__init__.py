"""Executable evaluation suites."""
