"""Executable M07-02 representation-construction scenarios."""

from __future__ import annotations

import argparse
import json
import sys
from dataclasses import asdict, dataclass
from pathlib import Path

if __package__ in {None, ""}:
    _PROJECT_ROOT = Path(__file__).resolve().parents[2]
    if str(_PROJECT_ROOT) not in sys.path:
        sys.path.insert(0, str(_PROJECT_ROOT))

from tests.modules.c07_copy_number.test_m07_02_representation import _request

from glio_proteogen.modules.c07_copy_number.m07_02_representation_feature_constructor import (
    M0702RepresentationEngine,
)


@dataclass(frozen=True, slots=True)
class EvaluationReport:
    module_id: str
    contract_version: str
    constructed_status: str
    leakage_abstained_status: str
    duplicate_source_abstained_status: str
    feature_count: int
    lineage_complete: bool
    replay_verified: bool
    deterministic: bool
    passed: bool


def evaluate() -> EvaluationReport:
    engine = M0702RepresentationEngine()
    first = engine.construct(_request())
    second = engine.construct(_request())
    leakage = engine.construct(_request(field="outcome_label"))
    duplicate_request = _request().model_copy(
        update={"source_artifacts": (_request().source_artifacts[0],) * 2}
    )
    duplicate = engine.construct(duplicate_request)
    replay = engine.verify(first.result, first.canonical_bytes)
    lineage_complete = all(
        feature.lineage.feature_id == feature.feature_id
        and feature.lineage.leakage_safe
        and bool(feature.lineage.source_fields)
        for feature in first.result.features
    )
    return EvaluationReport(
        module_id="GLIO-PROTEOGEN-M07-02",
        contract_version="0.1.0-provisional",
        constructed_status=first.result.status.value,
        leakage_abstained_status=leakage.result.status.value,
        duplicate_source_abstained_status=duplicate.result.status.value,
        feature_count=len(first.result.features),
        lineage_complete=lineage_complete,
        replay_verified=replay.verified,
        deterministic=first.canonical_bytes == second.canonical_bytes,
        passed=(
            first.result.status.value == "constructed"
            and leakage.result.status.value == "abstained"
            and duplicate.result.status.value == "abstained"
            and lineage_complete
            and replay.verified
            and first.canonical_bytes == second.canonical_bytes
        ),
    )


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    report = evaluate()
    rendered = json.dumps(asdict(report), indent=2, sort_keys=True)
    if args.output is not None:
        args.output.write_text(rendered + "\n", encoding="utf-8")
    sys.stdout.write(rendered + "\n")
    return 0 if report.passed else 1


if __name__ == "__main__":
    raise SystemExit(main())


__all__ = ["EvaluationReport", "evaluate", "main"]
