"""Locked public-contract behavior."""
